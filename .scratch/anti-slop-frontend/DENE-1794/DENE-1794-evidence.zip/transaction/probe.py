from pathlib import Path
import sys, subprocess, os
s=Path(sys.argv[1]).read_text().split('-- name: DeleteStoppedBotAccessToken :execrows')[1].split('-- name:')[0].strip()
for n in [1,2,3]: s=s.replace('$'+str(n),"'00000000-0000-4000-8000-00000000000"+str(n)+"'")
setup="""BEGIN;
CREATE TEMP TABLE personal_access_token(id uuid,workspace_id uuid,user_id uuid,kind text,revoked boolean,revoked_at timestamptz,deleted_at timestamptz,name text);
CREATE TEMP TABLE wake_event(bot_id uuid REFERENCES personal_access_token(id) ON DELETE CASCADE);
"""
# FK requires a unique target; temporary tables isolate the fixture from all real rows.
setup=setup.replace('id uuid,workspace_id','id uuid PRIMARY KEY,workspace_id')
setup+="INSERT INTO personal_access_token VALUES ('00000000-0000-4000-8000-000000000001','00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000000003','bot',true,NULL,NULL,'Grok');\nINSERT INTO wake_event VALUES ('00000000-0000-4000-8000-000000000001');\n"
query=setup+s+"\nSELECT 'credential_rows='||count(*) FROM personal_access_token; SELECT 'delivery_rows='||count(*) FROM wake_event; SELECT 'history_name='||name FROM personal_access_token; ROLLBACK;"
r=subprocess.run(['psql',os.environ['DATABASE_URL'],'-X','-qAt','-v','ON_ERROR_STOP=1'],input=query,text=True,capture_output=True)
print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr);sys.exit(r.returncode)
