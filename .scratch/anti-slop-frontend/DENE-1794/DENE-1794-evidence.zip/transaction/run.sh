#!/bin/sh
set -eu
base=/tmp/DENE-1794-transaction
for phase in BASELINE MODIFIED ROLLBACK; do
 case "$phase" in
 BASELINE) file="$base/BASELINE.sql";;
 MODIFIED) file="$base/MODIFIED_FILE.sql";;
 ROLLBACK) cp "$base/MODIFIED_FILE.sql" "$base/restored.sql"; "$base/ROLLBACK.sh" "$base/restored.sql"; file="$base/restored.sql";;
 esac
 echo "$phase command: python3 probe.py $file"
 python3 "$base/probe.py" "$file"
 echo "exit=$?"
 shasum -a 256 "$file"
done
cmp "$base/BASELINE.sql" "$base/restored.sql"
