package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/spf13/cobra"

	"github.com/multica-ai/multica/server/internal/cli"
	"github.com/multica-ai/multica/server/internal/daemon"
	"github.com/multica-ai/multica/server/internal/daemon/execenv"
)

var agentCmd = &cobra.Command{
	Use:   "agent",
	Short: "Work with agents",
}

var agentListCmd = &cobra.Command{
	Use:   "list",
	Short: "List agents in the workspace",
	Long: `List agents in the workspace.

With --for-issue or --for-project, each agent carries a "fit" for that work
and the list is ordered by it, the same judgement dispatch uses:
  match    对口 — a specialisation for the work's domain (in a generic scene, a base role)
  generic  通用 — a base role, the fallback
  other    其他 — a specialisation for another domain, still selectable
The work's domain is the issue's own domain, else its project's domains,
else generic.`,
	RunE: runAgentList,
}

var agentGetCmd = &cobra.Command{
	Use:   "get <id>",
	Short: "Get agent details",
	Args:  exactArgs(1),
	RunE:  runAgentGet,
}

var agentCreateCmd = &cobra.Command{
	Use:   "create",
	Short: "Create a new agent",
	RunE:  runAgentCreate,
}

var agentUpdateCmd = &cobra.Command{
	Use:   "update <id>",
	Short: "Update an agent",
	Args:  exactArgs(1),
	RunE:  runAgentUpdate,
}

var agentArchiveCmd = &cobra.Command{
	Use:   "archive <id>",
	Short: "Archive an agent",
	Args:  exactArgs(1),
	RunE:  runAgentArchive,
}

// Solidify is the non-lossy way out of a specialisation: the base role's
// prompt is written into the agent's own instructions BEFORE the link is
// cleared, so what the daemon is handed does not change. `agent update
// --parent-agent-id ""` is the lossy counterpart and stays available for the
// case where dropping the inherited text is the point.
var agentSolidifyCmd = &cobra.Command{
	Use:   "solidify <id>",
	Short: "Bake a specialisation's inherited prompt into its own and detach it from its base role",
	Args:  exactArgs(1),
	RunE:  runAgentSolidify,
}

var agentRestoreCmd = &cobra.Command{
	Use:   "restore <id>",
	Short: "Restore an archived agent",
	Args:  exactArgs(1),
	RunE:  runAgentRestore,
}

var agentTasksCmd = &cobra.Command{
	Use:   "tasks <id>",
	Short: "List runs for an agent",
	Args:  exactArgs(1),
	RunE:  runAgentTasks,
}

var agentChatsCmd = &cobra.Command{
	Use:   "chats <agent>",
	Short: "List an agent's open chats, busy first",
	Long: `List an agent's open chats, running first, then queued, then idle.

A chat you are not allowed to open is still listed, because it holds the
agent's concurrency like any other, but without its title or creator.`,
	Args: exactArgs(1),
	RunE: runAgentChats,
}

var agentAvatarCmd = &cobra.Command{
	Use:   "avatar <id>",
	Short: "Upload an avatar image for an agent",
	Args:  exactArgs(1),
	RunE:  runAgentAvatar,
}

// Agent skills subcommands.

var agentSkillsCmd = &cobra.Command{
	Use:   "skills",
	Short: "Manage agent skill assignments",
}

// Agent env subcommands. Live behind a dedicated `agent env` group because
// they're the ONLY post-creation path for reading or writing
// custom_env values — `multica agent list / get / update` no longer
// expose env on the wire. Each call hits the audited
// `/api/agents/{id}/env` endpoint. See MUL-2600.

var agentEnvCmd = &cobra.Command{
	Use:   "env",
	Short: "Read and update an agent's custom environment variables (audited)",
}

var agentEnvGetCmd = &cobra.Command{
	Use:   "get <agent-id>",
	Short: "Print an agent's custom_env as a JSON map (agent owner or workspace owner/admin; every call is recorded)",
	Args:  exactArgs(1),
	RunE:  runAgentEnvGet,
}

var agentEnvSetCmd = &cobra.Command{
	Use:   "set <agent-id>",
	Short: "Replace an agent's custom_env (agent owner or workspace owner/admin; values equal to **** preserve the existing entry)",
	Args:  exactArgs(1),
	RunE:  runAgentEnvSet,
}

var agentSkillsListCmd = &cobra.Command{
	Use:   "list <agent-id>",
	Short: "List skills assigned to an agent",
	Args:  exactArgs(1),
	RunE:  runAgentSkillsList,
}

var agentSkillsSetCmd = &cobra.Command{
	Use:   "set <agent-id>",
	Short: "Set skills for an agent (replaces all current assignments)",
	Args:  exactArgs(1),
	RunE:  runAgentSkillsSet,
}

var agentSkillsAddCmd = &cobra.Command{
	Use:   "add <agent-id>",
	Short: "Add skills to an agent without replacing existing assignments",
	Args:  exactArgs(1),
	RunE:  runAgentSkillsAdd,
}

func init() {
	agentCmd.AddCommand(agentListCmd)
	agentCmd.AddCommand(agentGetCmd)
	agentCmd.AddCommand(agentCreateCmd)
	agentCmd.AddCommand(agentUpdateCmd)
	agentCmd.AddCommand(agentArchiveCmd)
	agentCmd.AddCommand(agentRestoreCmd)
	agentCmd.AddCommand(agentSolidifyCmd)
	agentCmd.AddCommand(agentTasksCmd)
	agentCmd.AddCommand(agentChatsCmd)
	agentCmd.AddCommand(agentAvatarCmd)
	agentCmd.AddCommand(agentSkillsCmd)
	agentCmd.AddCommand(agentEnvCmd)

	agentSkillsCmd.AddCommand(agentSkillsListCmd)
	agentSkillsCmd.AddCommand(agentSkillsSetCmd)
	agentSkillsCmd.AddCommand(agentSkillsAddCmd)

	agentEnvCmd.AddCommand(agentEnvGetCmd)
	agentEnvCmd.AddCommand(agentEnvSetCmd)

	// agent list
	agentListCmd.Flags().String("output", "table", "Output format: table or json")
	agentListCmd.Flags().Bool("include-archived", false, "Include archived agents")
	agentListCmd.Flags().String("for-issue", "", "Group agents by fit for this issue (key or UUID); adds a fit field")
	agentListCmd.Flags().String("for-project", "", "Group agents by fit for this project (UUID or prefix); adds a fit field")

	// agent get
	agentGetCmd.Flags().String("output", "json", "Output format: table or json")

	// agent create
	agentCreateCmd.Flags().String("name", "", "Agent name (required unless --domain is given, which names the seat base role + domain)")
	agentCreateCmd.Flags().String("description", "", "Agent description")
	agentCreateCmd.Flags().String("instructions", "", "Agent instructions")
	agentCreateCmd.Flags().String("conversation-starters", "", "Conversation starters as a JSON array of {\"label\",\"prompt\"} objects (at most 3; label ≤80, prompt ≤4000). Shown above the Chat composer; selecting one fills the composer and does not start a run. Omit to default to none.")
	agentCreateCmd.Flags().String("runtime-id", "", "Runtime ID (required unless the new agent specialises a base role, which inherits that base role's runtime by default)")
	agentCreateCmd.Flags().String("runtime-config", "", "Runtime config as JSON string")
	agentCreateCmd.Flags().String("model", "", "Model identifier (e.g. claude-sonnet-4-6, openai/gpt-4o). Prefer this over passing --model in --custom-args.")
	agentCreateCmd.Flags().String("thinking-level", "", "Reasoning/effort level for the agent's runtime (e.g. Claude: low|medium|high|xhigh|max; Codex values come from the runtime model catalog). The set is runtime/model-specific; malformed values are rejected server-side and the daemon validates the exact model/level pair. Some runtimes (e.g. hermes) expose no reasoning control and reject every value. Empty = runtime default.")
	agentCreateCmd.Flags().String("routing-tier", "", "Seat strength for automatic dispatch: strongest|strong|medium|weak (the Chinese labels 最强/强/中/弱 are accepted too). Empty leaves the seat off the routing ladder; a specialisation with no value inherits its base role's tier.")
	agentCreateCmd.Flags().String("service-tier", "", "Codex execution speed: empty = inherit local Codex configuration; default = explicit Standard when supported by the daemon's installed Codex CLI; a catalog tier such as priority = explicit Fast.")
	agentCreateCmd.Flags().String("custom-args", "", "Custom CLI arguments as JSON array. For model selection prefer --model; Codex-style -c key=value is rejected on runtimes that reserve -c for session continuation (Claude, CodeBuddy, OpenCode, Pi and others), and session-resume flags are always dropped because the daemon owns which session a run continues.")
	agentCreateCmd.Flags().String("custom-env", "", "Custom environment variables as JSON object, e.g. '{\"KEY\":\"value\"}'. Treated as secret material — never logged by the CLI, but values passed on the command line are visible to shell history and 'ps'; prefer --custom-env-stdin or --custom-env-file for real secrets. Pass '{}' to set an empty map.")
	agentCreateCmd.Flags().Bool("custom-env-stdin", false, "Read the --custom-env JSON object from stdin. Keeps secrets out of shell history and 'ps'. Mutually exclusive with --custom-env and --custom-env-file.")
	agentCreateCmd.Flags().String("custom-env-file", "", "Read the --custom-env JSON object from a file path (suggested mode: 0600). Mutually exclusive with --custom-env and --custom-env-stdin.")
	agentCreateCmd.Flags().String("mcp-config", "", "MCP server configuration as a JSON object, e.g. '{\"mcpServers\":{\"shortcut\":{...}}}'. Treated as secret material (MCP entries often carry API tokens) — never logged by the CLI, but values passed on the command line are visible to shell history and 'ps'; prefer --mcp-config-stdin or --mcp-config-file for real secrets.")
	agentCreateCmd.Flags().Bool("mcp-config-stdin", false, "Read the --mcp-config JSON object from stdin. Keeps secrets out of shell history and 'ps'. Mutually exclusive with --mcp-config and --mcp-config-file.")
	agentCreateCmd.Flags().String("mcp-config-file", "", "Read the --mcp-config JSON object from a file path (suggested mode: 0600). Mutually exclusive with --mcp-config and --mcp-config-stdin.")
	agentCreateCmd.Flags().String("visibility", "private", "Visibility: private or workspace (legacy; mapped to --permission-mode. private->private, workspace->public_to+workspace target)")
	agentCreateCmd.Flags().String("permission-mode", "", "Invocation permission mode: private (owner only) or public_to (allow-list via --public-to-*). Authoritative over --visibility when set.")
	agentCreateCmd.Flags().Bool("public-to-workspace", false, "public_to: allow every workspace member to invoke this agent.")
	agentCreateCmd.Flags().StringSlice("public-to-member", nil, "public_to: allow the given member user id(s) to invoke this agent. Repeatable.")
	agentCreateCmd.Flags().Int32("max-concurrent-tasks", 6, "Maximum concurrent runs (1-50)")
	agentCreateCmd.Flags().String("parent-agent-id", "", "Base role to specialise: the new agent inherits that agent's prompt (prepended at run time), skills, and — unless --runtime-inherited=false — its runtime configuration (runtime, model, thinking level). Must be a base role itself — a specialisation cannot be specialised further. Empty = an independent base role.")
	agentCreateCmd.Flags().String("base-role", "", "Base role to specialise, by name or id (same as --parent-agent-id, which takes an id)")
	agentCreateCmd.Flags().String("domain", "", "Workspace domain of the new specialisation (needs --base-role). The name becomes base role + domain; a base role has one specialisation per domain. See `multica domain list`")
	agentCreateCmd.Flags().Bool("runtime-inherited", false, "Specialisation only: follow the base role's runtime configuration (runtime_id, model, thinking_level, service_tier, runtime_config). Default for a specialisation; pass --runtime-inherited=false together with --runtime-id to give it its own. Rejected without --parent-agent-id.")
	agentCreateCmd.Flags().String("output", "json", "Output format: table or json")

	// agent update
	agentUpdateCmd.Flags().String("name", "", "New name")
	agentUpdateCmd.Flags().String("description", "", "New description")
	agentUpdateCmd.Flags().String("instructions", "", "New instructions")
	agentUpdateCmd.Flags().String("conversation-starters", "", "New conversation starters as a JSON array of {\"label\",\"prompt\"} objects (at most 3; label ≤80, prompt ≤4000). Pass '[]' to clear. Omit to leave the stored value unchanged.")
	agentUpdateCmd.Flags().String("runtime-id", "", "New runtime ID")
	agentUpdateCmd.Flags().String("runtime-config", "", "New runtime config as JSON string")
	agentUpdateCmd.Flags().String("model", "", "New model identifier. Pass an empty string to clear and fall back to the runtime default.")
	agentUpdateCmd.Flags().String("thinking-level", "", "New reasoning/effort level for the agent's runtime (e.g. Claude: low|medium|high|xhigh|max; Codex values come from the runtime model catalog). The set is runtime/model-specific; malformed values are rejected server-side and the daemon validates the exact model/level pair. Some runtimes (e.g. hermes) expose no reasoning control and reject every value. Pass an empty string to clear and fall back to the runtime default.")
	agentUpdateCmd.Flags().String("routing-tier", "", "New seat strength for automatic dispatch: strongest|strong|medium|weak (the Chinese labels 最强/强/中/弱 are accepted too). Pass an empty string to take the seat off the routing ladder. A specialisation that follows its base role cannot set this; change the base role, or pass --runtime-inherited=false first.")
	agentUpdateCmd.Flags().String("dispatch-mode", "", "Whether automatic dispatch may pick this seat: auto|mention_only. mention_only seats are still reached by @mention, assignment and delegation, but routing, quota relay and seat relay never pick them. Independent of --routing-tier and --work-enabled. A specialisation that follows its base role cannot set this; change the base role, or pass --runtime-inherited=false first.")
	agentUpdateCmd.Flags().String("dispatch-projects", "", "Limit automatic dispatch to tickets in these projects: comma-separated project ids, id prefixes or exact titles. Routing, quota relay and seat relay pick the seat only for tickets in one of them; @mention, assignment and delegation are not limited. Pass an empty value to serve every project again.")
	agentUpdateCmd.Flags().String("routing-usage", "", "New usage tag for automatic dispatch: tight|normal|ample (the Chinese labels 紧张/常规/充足 are accepted too). A specialisation that follows its base role cannot set this; change the base role, or pass --runtime-inherited=false first.")
	agentUpdateCmd.Flags().String("service-tier", "", "New Codex execution speed: default = explicit Standard when supported by the daemon's installed Codex CLI; a catalog tier such as priority = explicit Fast. Pass an empty string to clear and inherit local Codex configuration.")
	agentUpdateCmd.Flags().String("custom-args", "", "New custom CLI arguments as JSON array. For model selection prefer --model; Codex-style -c key=value is rejected on runtimes that reserve -c for session continuation (Claude, CodeBuddy, OpenCode, Pi and others), and session-resume flags are always dropped because the daemon owns which session a run continues.")
	// custom_env is intentionally NOT part of `agent update`. Use
	// `multica agent env set <id>` — that path admits the agent owner or a
	// workspace owner/admin, denies agent actors, and writes a persisted
	// audit trail.
	//
	// mcp_config, unlike custom_env, IS updatable here: it is persisted
	// through the generic UpdateAgent endpoint (there is no dedicated
	// audited endpoint for it). The same three secret-safe input channels
	// as `agent create` are offered. Pass `--mcp-config null` to clear.
	agentUpdateCmd.Flags().String("mcp-config", "", "New MCP server configuration as a JSON object, e.g. '{\"mcpServers\":{...}}'. Pass 'null' to clear. Treated as secret material — never logged by the CLI, but values passed on the command line are visible to shell history and 'ps'; prefer --mcp-config-stdin or --mcp-config-file for real secrets.")
	agentUpdateCmd.Flags().Bool("mcp-config-stdin", false, "Read the --mcp-config JSON from stdin. Keeps secrets out of shell history and 'ps'. Mutually exclusive with --mcp-config and --mcp-config-file.")
	agentUpdateCmd.Flags().String("mcp-config-file", "", "Read the --mcp-config JSON from a file path (suggested mode: 0600). Mutually exclusive with --mcp-config and --mcp-config-stdin.")
	agentUpdateCmd.Flags().String("visibility", "", "New visibility: private or workspace (legacy; mapped to --permission-mode)")
	agentUpdateCmd.Flags().String("permission-mode", "", "New invocation permission mode: private or public_to. Authoritative over --visibility. Owner-only.")
	agentUpdateCmd.Flags().Bool("public-to-workspace", false, "public_to: allow every workspace member to invoke this agent.")
	agentUpdateCmd.Flags().StringSlice("public-to-member", nil, "public_to: allow the given member user id(s) to invoke this agent. Repeatable.")
	agentUpdateCmd.Flags().String("status", "", "New status")
	agentUpdateCmd.Flags().Int32("max-concurrent-tasks", 0, "New max concurrent runs (1-50)")
	agentUpdateCmd.Flags().String("parent-agent-id", "", "Attach this existing agent to a base role, or pass an empty string to detach it. Detaching here does NOT keep the inherited prompt — use 'multica agent solidify <id>' for the non-lossy unbind. An agent that already has specialisations cannot be attached (two levels only).")
	agentUpdateCmd.Flags().Bool("runtime-inherited", false, "Follow the base role's runtime configuration (true), or keep this agent's own (false). Copied immediately in both directions; opting out keeps the values the agent is running with now. Refused on a base role, and refused in the same call as a runtime flag (--runtime-id/--model/--thinking-level/--service-tier/--runtime-config) while following.")
	agentUpdateCmd.Flags().Bool("work-enabled", true, "Open (true) or close (false) the seat for work, e.g. --work-enabled=false. A closed seat refuses new runs and stays out of dispatch. On a base role every specialisation follows. Turning a seat back on also requeues the todo / in_progress issues it still owns that have no run.")
	agentUpdateCmd.Flags().String("output", "json", "Output format: table or json")

	// agent archive
	agentArchiveCmd.Flags().String("output", "json", "Output format: table or json")

	// agent restore
	agentRestoreCmd.Flags().String("output", "json", "Output format: table or json")

	// agent solidify
	agentSolidifyCmd.Flags().String("output", "json", "Output format: table or json")

	// agent tasks
	agentTasksCmd.Flags().String("output", "table", "Output format: table or json")
	agentTasksCmd.Flags().Int("limit", 200, "Maximum runs per page (1-200)")
	agentTasksCmd.Flags().String("before", "", "Cursor from the previous page")

	// agent chats
	agentChatsCmd.Flags().String("output", "table", "Output format: table or json")
	agentChatsCmd.Flags().Int("limit", 20, "Maximum chats to list (1-100)")

	// agent avatar
	agentAvatarCmd.Flags().String("file", "", "Path to the avatar image file (required)")
	agentAvatarCmd.Flags().String("output", "json", "Output format: table or json")

	// agent skills list
	agentSkillsListCmd.Flags().String("output", "table", "Output format: table or json")

	// agent skills set
	agentSkillsSetCmd.Flags().StringSlice("skill-ids", nil, "Skill IDs to assign (comma-separated)")
	agentSkillsSetCmd.Flags().String("output", "json", "Output format: table or json")

	// agent skills add
	agentSkillsAddCmd.Flags().StringSlice("skill-ids", nil, "Skill IDs to add (comma-separated)")
	agentSkillsAddCmd.Flags().String("output", "json", "Output format: table or json")

	// agent env get
	agentEnvGetCmd.Flags().String("output", "json", "Output format: json or table")

	// agent env set. Same three secret-safe input channels as `agent
	// create` so scripts can keep secrets out of shell history. Mutual
	// exclusion + empty-input handling is enforced by resolveCustomEnv.
	agentEnvSetCmd.Flags().String("custom-env", "", "Replacement custom_env as a JSON object, e.g. '{\"KEY\":\"value\"}'. Values equal to '****' preserve the existing entry. Treated as secret material — values passed on the command line are visible to shell history and 'ps'; prefer --custom-env-stdin or --custom-env-file for real secrets. Pass '{}' to clear all keys.")
	agentEnvSetCmd.Flags().Bool("custom-env-stdin", false, "Read the replacement custom_env JSON object from stdin. Keeps secrets out of shell history and 'ps'. Mutually exclusive with --custom-env and --custom-env-file.")
	agentEnvSetCmd.Flags().String("custom-env-file", "", "Read the replacement custom_env JSON object from a file path (suggested mode: 0600). Mutually exclusive with --custom-env and --custom-env-stdin.")
	agentEnvSetCmd.Flags().String("output", "json", "Output format: json or table")
}

// resolveProfile returns the --profile flag value (empty string means default profile).
func resolveProfile(cmd *cobra.Command) string {
	val, _ := cmd.Flags().GetString("profile")
	return val
}

func newAPIClient(cmd *cobra.Command) (*cli.APIClient, error) {
	taskContext := inDaemonManagedExecutionContext()
	token := resolveToken(cmd)
	if taskContext && !strings.HasPrefix(token, "mat_") {
		// When the ONLY daemon signal is a workdir marker (no MULTICA_AGENT_ID /
		// MULTICA_TASK_ID / MULTICA_DAEMON_PORT), the likeliest cause outside a
		// real task is a leftover marker from a crashed daemon task in a
		// local_directory. Name the exact file so a normal user can recover
		// instead of hitting an opaque "requires mat_ token" error. Shares its
		// wording with requireHumanLocalCommand: same cause, same remedy.
		if markerPath := leftoverDaemonTaskMarkerPath(); markerPath != "" {
			return nil, fmt.Errorf("agent execution context requires MULTICA_TOKEN to be a task-scoped mat_ token%s", leftoverMarkerSuffix(markerPath))
		}
		return nil, fmt.Errorf("agent execution context requires MULTICA_TOKEN to be a task-scoped mat_ token%s", daemonPortOnlyContextHint())
	}

	serverURL := resolveServerURL(cmd)
	workspaceID := resolveWorkspaceID(cmd)
	if serverURL == "" {
		return nil, fmt.Errorf("server URL not set: use --server-url flag, MULTICA_SERVER_URL env, or 'multica config set server_url <url>'")
	}

	client := cli.NewAPIClient(serverURL, workspaceID, token)
	// When running inside a daemon task, attribute actions to the agent.
	if agentID := os.Getenv("MULTICA_AGENT_ID"); agentID != "" {
		client.AgentID = agentID
	}
	if taskID := os.Getenv("MULTICA_TASK_ID"); taskID != "" {
		client.TaskID = taskID
	}
	client.LocalCopyURL = localCopyURL(token)
	if linked, _ := cmd.Flags().GetString(linkedFlag); strings.TrimSpace(linked) != "" {
		if err := useLinkedWorkspace(client, strings.TrimSpace(linked)); err != nil {
			return nil, err
		}
	}
	return client, nil
}

// localCopyURL is where uploads leave their local copy: the hosting daemon's
// /outputs endpoint, only inside a daemon-managed task that carries its task
// token. Anywhere else no copy is kept.
func localCopyURL(token string) string {
	if !inDaemonTaskIdentityContext() || !strings.HasPrefix(token, "mat_") {
		return ""
	}
	port, err := strconv.Atoi(strings.TrimSpace(os.Getenv("MULTICA_DAEMON_PORT")))
	if err != nil || port <= 0 {
		return ""
	}
	return fmt.Sprintf("http://127.0.0.1:%d/outputs", port)
}

const (
	defaultCloudServerURL = "https://api.multica.ai"
	defaultCloudAppURL    = "https://multica.ai"
)

func tryResolveServerURL(cmd *cobra.Command) string {
	if val := tryResolveExplicitServerURL(cmd); val != "" {
		return val
	}
	if inDaemonManagedExecutionContext() && strings.TrimSpace(os.Getenv(cli.TaskConfigRootEnv)) == "" {
		return ""
	}
	return tryResolveProfileServerURL(cmd)
}

// tryResolveHumanServerURL is reserved for a human/local command after it has
// passed requireHumanLocalCommand. Unlike the general resolver, a stale
// MULTICA_DAEMON_PORT in a host/container environment must not hide the human
// profile that login is explicitly meant to update.
func tryResolveHumanServerURL(cmd *cobra.Command) string {
	if val := tryResolveExplicitServerURL(cmd); val != "" {
		return val
	}
	return tryResolveProfileServerURL(cmd)
}

func tryResolveExplicitServerURL(cmd *cobra.Command) string {
	val := cli.FlagOrEnv(cmd, "server-url", "MULTICA_SERVER_URL", "")
	if val == "" {
		return ""
	}
	return normalizeAPIBaseURL(val)
}

func tryResolveProfileServerURL(cmd *cobra.Command) string {
	profile := resolveProfile(cmd)
	cfg, err := cli.LoadCLIConfigForProfile(profile)
	if err == nil && cfg.ServerURL != "" {
		return normalizeAPIBaseURL(cfg.ServerURL)
	}
	return ""
}

func resolveServerURL(cmd *cobra.Command) string {
	if val := tryResolveServerURL(cmd); val != "" {
		return val
	}
	fmt.Fprintln(os.Stderr, missingServerConfigMessage())
	os.Exit(1)
	return "" // unreachable
}

func missingServerConfigMessage() string {
	return fmt.Sprintf("No server configured. Run 'multica setup' first%s.", daemonPortOnlyContextHint())
}

func resolveHumanServerURL(cmd *cobra.Command) string {
	if val := tryResolveHumanServerURL(cmd); val != "" {
		return val
	}
	fmt.Fprintln(os.Stderr, "No server configured. Run 'multica setup' first.")
	os.Exit(1)
	return "" // unreachable
}

func resolveLoginTokenServerURL(cmd *cobra.Command) string {
	if val := tryResolveHumanServerURL(cmd); val != "" {
		return val
	}
	return defaultCloudServerURL
}

func normalizeAPIBaseURL(raw string) string {
	normalized, err := daemon.NormalizeServerBaseURL(raw)
	if err == nil {
		return normalized
	}
	return raw
}

// inAgentExecutionContext reports whether the CLI has explicit task identity
// markers from a daemon-managed agent task.
func inAgentExecutionContext() bool {
	return os.Getenv("MULTICA_AGENT_ID") != "" || os.Getenv("MULTICA_TASK_ID") != ""
}

// inDaemonManagedExecutionContext reports whether the CLI is being invoked
// from inside a daemon-managed agent task. MULTICA_DAEMON_PORT is included as
// a defense-in-depth marker for subprocesses that lose MULTICA_AGENT_ID or
// MULTICA_TASK_ID but still run under the daemon environment. In this context
// workspace and token must come from daemon-provided env; falling back to
// user-global ~/.multica/config.json can make agent writes land as a member.
func inDaemonManagedExecutionContext() bool {
	return inAgentExecutionContext() || os.Getenv("MULTICA_DAEMON_PORT") != "" || hasDaemonTaskContextMarker()
}

// inDaemonTaskIdentityContext reports strong evidence that the current process
// belongs to a daemon-managed task. MULTICA_DAEMON_PORT is deliberately not
// sufficient: older host/container setups may export that otherwise inert
// task hint before login or daemon startup.
func inDaemonTaskIdentityContext() bool {
	return inAgentExecutionContext() ||
		strings.TrimSpace(os.Getenv(cli.TaskConfigRootEnv)) != "" ||
		hasDaemonTaskContextMarker()
}

func daemonPortOnlyContextHint() string {
	if strings.TrimSpace(os.Getenv("MULTICA_DAEMON_PORT")) == "" || inDaemonTaskIdentityContext() {
		return ""
	}
	return "; MULTICA_DAEMON_PORT is set without task identity — if this is a host or container startup shell, remove that variable and retry"
}

// requireTaskLocalConfigRoot prevents daemon-managed subprocesses that lost
// part of their injected environment from silently resolving Multica state
// below the daemon owner's HOME. Commands that intentionally support task-local
// config (currently config show/set and auth status) call this before any load.
func requireTaskLocalConfigRoot() error {
	if !inDaemonManagedExecutionContext() {
		return nil
	}
	if strings.TrimSpace(os.Getenv(cli.TaskConfigRootEnv)) == "" {
		// The third refusal path a leftover marker can trigger, alongside
		// newAPIClient and requireHumanLocalCommand. It has to name the file
		// too: a user hitting this one through `config show` or `auth status`
		// is as stuck as one hitting the others, and "which command did you
		// happen to run first" must not decide whether the error is actionable.
		if markerPath := leftoverDaemonTaskMarkerPath(); markerPath != "" {
			return fmt.Errorf("daemon-managed task requires a task-local Multica config root in %s%s", cli.TaskConfigRootEnv, leftoverMarkerSuffix(markerPath))
		}
		return fmt.Errorf("daemon-managed task requires a task-local Multica config root in %s%s", cli.TaskConfigRootEnv, daemonPortOnlyContextHint())
	}
	return nil
}

// requireHumanLocalCommand rejects commands whose purpose is to authenticate,
// set up, or operate the human-owned local daemon/profile. Task API commands
// remain available with the injected mat_ token; these local commands do not.
func requireHumanLocalCommand(command string) error {
	if !inDaemonTaskIdentityContext() {
		return nil
	}
	// A task-scoped workdir marker with no task identity in the environment is
	// the one signal that can outlive the task that wrote it: a local_directory
	// run that never cleaned up leaves it in the user's own repository, where it
	// disables every command below this function for that whole directory tree
	// until someone deletes the file by hand (MUL-6132). Name it, so the user
	// knows which file that is; the bare message below sends them to the source
	// instead. Mirrors newAPIClient's leftover-marker handling.
	if markerPath := leftoverDaemonTaskMarkerPath(); markerPath != "" {
		return fmt.Errorf("%s is not available inside a daemon-managed task%s", command, leftoverMarkerSuffix(markerPath))
	}
	return fmt.Errorf("%s is not available inside a daemon-managed task", command)
}

func hasDaemonTaskContextMarker() bool {
	return daemonTaskContextMarkerPath() != ""
}

// daemonTaskContextMarkerPath walks up from the current working directory and
// returns the path of the first readable daemon-task marker whose managed_by
// matches, or "" when none is found.
func daemonTaskContextMarkerPath() string {
	dir, err := os.Getwd()
	if err != nil {
		return ""
	}
	for {
		markerPath := filepath.Join(dir, execenv.TaskContextMarkerRelPath)
		// Only a marker we can read AND whose managed_by matches counts as a
		// daemon-task signal. Any other outcome — missing file, unreadable
		// path, or a foreign file at this name — is treated as "no signal
		// here", so we keep walking up. We must not fail closed on an
		// unrelated read error (e.g. an unsearchable ancestor directory on a
		// normal user's machine), which would refuse their PAT for no reason;
		// the daemon writes this marker world-readable in the agent's own
		// workdir, so a legitimate agent can always read it.
		if data, err := os.ReadFile(markerPath); err == nil {
			var marker struct {
				ManagedBy string `json:"managed_by"`
			}
			if json.Unmarshal(data, &marker) == nil && marker.ManagedBy == execenv.TaskContextMarkerManagedBy {
				return markerPath
			}
		}

		parent := filepath.Dir(dir)
		if parent == dir {
			return ""
		}
		dir = parent
	}
}

func resolveWorkspaceID(cmd *cobra.Command) string {
	val := cli.FlagOrEnv(cmd, "workspace-id", "MULTICA_WORKSPACE_ID", "")
	if val != "" {
		return val
	}
	// Inside an agent task the daemon is the only authority on workspace
	// identity. Never read the user-global CLI config here.
	if inDaemonManagedExecutionContext() {
		return ""
	}
	profile := resolveProfile(cmd)
	cfg, _ := cli.LoadCLIConfigForProfile(profile)
	return cfg.WorkspaceID
}

// requireWorkspaceID resolves the workspace ID and returns an error with
// actionable instructions if it is empty (e.g. user has multiple workspaces
// but no default configured).
func requireWorkspaceID(cmd *cobra.Command) (string, error) {
	id := resolveWorkspaceID(cmd)
	if id == "" {
		if inDaemonManagedExecutionContext() {
			return "", fmt.Errorf("workspace_id is required: MULTICA_WORKSPACE_ID must be set by the daemon in agent execution context (no fallback to user config)")
		}
		return "", fmt.Errorf("workspace_id is required: use --workspace-id flag, set MULTICA_WORKSPACE_ID env, or run 'multica config set workspace_id <id>'")
	}
	return id, nil
}

// ---------------------------------------------------------------------------
// Agent commands
// ---------------------------------------------------------------------------

func runAgentList(cmd *cobra.Command, _ []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}
	if client.WorkspaceID == "" {
		if _, err := requireWorkspaceID(cmd); err != nil {
			return err
		}
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var agents []map[string]any
	params := url.Values{}
	params.Set("workspace_id", client.WorkspaceID)
	if v, _ := cmd.Flags().GetBool("include-archived"); v {
		params.Set("include_archived", "true")
	}
	forIssue, _ := cmd.Flags().GetString("for-issue")
	forProject, _ := cmd.Flags().GetString("for-project")
	if forIssue != "" && forProject != "" {
		return fmt.Errorf("--for-issue and --for-project are exclusive")
	}
	if forIssue != "" {
		ref, err := resolveIssueRef(ctx, client, forIssue)
		if err != nil {
			return fmt.Errorf("resolve issue: %w", err)
		}
		params.Set("for_issue", ref.ID)
	}
	if forProject != "" {
		ref, err := resolveProjectID(ctx, client, forProject)
		if err != nil {
			return fmt.Errorf("resolve project: %w", err)
		}
		params.Set("for_project", ref.ID)
	}
	withFit := forIssue != "" || forProject != ""
	path := "/api/agents"
	if len(params) > 0 {
		path += "?" + params.Encode()
	}
	if err := client.GetJSON(ctx, path, &agents); err != nil {
		return fmt.Errorf("list agents: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, agents)
	}

	headers := []string{"ID", "NAME", "STATUS", "RUNTIME", "ARCHIVED"}
	if withFit {
		headers = append(headers, "FIT")
	}
	rows := make([][]string, 0, len(agents))
	for _, a := range agents {
		archived := ""
		if v := strVal(a, "archived_at"); v != "" {
			archived = "yes"
		}
		row := []string{
			strVal(a, "id"),
			strVal(a, "name"),
			strVal(a, "status"),
			strVal(a, "runtime_mode"),
			archived,
		}
		if withFit {
			row = append(row, strVal(a, "fit"))
		}
		rows = append(rows, row)
	}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

func runAgentGet(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var agent map[string]any
	if err := client.GetJSON(ctx, "/api/agents/"+args[0], &agent); err != nil {
		return fmt.Errorf("get agent: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, agent)
	}

	headers := []string{"ID", "NAME", "STATUS", "RUNTIME", "VISIBILITY", "AVATAR_URL", "DESCRIPTION"}
	rows := [][]string{{
		strVal(agent, "id"),
		strVal(agent, "name"),
		strVal(agent, "status"),
		strVal(agent, "runtime_mode"),
		strVal(agent, "visibility"),
		strVal(agent, "avatar_url"),
		strVal(agent, "description"),
	}}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

// applyAgentPermissionFlags translates the invocation-permission flags
// (--permission-mode / --public-to-workspace / --public-to-member) into the
// permission_mode + invocation_targets request fields (MUL-3963). When none of
// the flags are set it is a no-op, so the legacy --visibility handling still
// drives the request. When any public-to-* flag is present without an explicit
// --permission-mode, the mode defaults to public_to.
func applyAgentPermissionFlags(cmd *cobra.Command, body map[string]any) {
	hasMode := cmd.Flags().Changed("permission-mode")
	hasWorkspace := cmd.Flags().Changed("public-to-workspace")
	hasMembers := cmd.Flags().Changed("public-to-member")
	if !hasMode && !hasWorkspace && !hasMembers {
		return
	}

	mode := "public_to"
	if hasMode {
		mode, _ = cmd.Flags().GetString("permission-mode")
	}
	body["permission_mode"] = mode

	targets := []map[string]any{}
	if on, _ := cmd.Flags().GetBool("public-to-workspace"); on {
		targets = append(targets, map[string]any{"target_type": "workspace"})
	}
	if members, _ := cmd.Flags().GetStringSlice("public-to-member"); len(members) > 0 {
		for _, m := range members {
			targets = append(targets, map[string]any{"target_type": "member", "target_id": m})
		}
	}
	body["invocation_targets"] = targets
}

func runAgentCreate(cmd *cobra.Command, _ []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	name, _ := cmd.Flags().GetString("name")
	domain, _ := cmd.Flags().GetString("domain")
	domain = strings.TrimSpace(domain)
	if name == "" && domain == "" {
		return fmt.Errorf("--name is required (or --base-role with --domain, which names the seat)")
	}
	runtimeID, _ := cmd.Flags().GetString("runtime-id")
	parentAgentID, _ := cmd.Flags().GetString("parent-agent-id")
	parentAgentID = strings.TrimSpace(parentAgentID)
	if baseRole, _ := cmd.Flags().GetString("base-role"); strings.TrimSpace(baseRole) != "" {
		if parentAgentID != "" {
			return fmt.Errorf("--base-role and --parent-agent-id name the same thing; pass one")
		}
		resolveCtx, resolveCancel := cli.APIContext(context.Background())
		id, err := resolveAgent(resolveCtx, client, strings.TrimSpace(baseRole))
		resolveCancel()
		if err != nil {
			return fmt.Errorf("resolve base role: %w", err)
		}
		parentAgentID = id
	}
	if domain != "" && parentAgentID == "" {
		return fmt.Errorf("--domain needs --base-role: only a specialisation works in a domain")
	}

	// Runtime inheritance (DENE-505). A specialisation follows its base role's
	// runtime configuration unless the caller opts out, which is why --runtime-id
	// stops being required the moment --parent-agent-id is given: the runtime is
	// then the base role's. runtime_inherited is sent only when the flag was set,
	// so omitting it keeps the server's "follow" default instead of restating it.
	inheritRuntime := parentAgentID != ""
	if cmd.Flags().Changed("runtime-inherited") {
		inheritRuntime, _ = cmd.Flags().GetBool("runtime-inherited")
		if inheritRuntime && parentAgentID == "" {
			return fmt.Errorf("--runtime-inherited needs --parent-agent-id: only a specialisation can follow a base role's runtime")
		}
	}
	if runtimeID == "" && !inheritRuntime {
		return fmt.Errorf("--runtime-id is required")
	}

	body := map[string]any{
		"name": name,
	}
	if runtimeID != "" {
		body["runtime_id"] = runtimeID
	}
	if cmd.Flags().Changed("runtime-inherited") {
		body["runtime_inherited"] = inheritRuntime
	}
	if v, _ := cmd.Flags().GetString("description"); v != "" {
		body["description"] = v
	}
	if v, _ := cmd.Flags().GetString("instructions"); v != "" {
		body["instructions"] = v
	}
	if err := applyConversationStartersFlag(cmd, body); err != nil {
		return err
	}
	if cmd.Flags().Changed("runtime-config") {
		v, _ := cmd.Flags().GetString("runtime-config")
		var rc any
		if err := json.Unmarshal([]byte(v), &rc); err != nil {
			return fmt.Errorf("--runtime-config must be valid JSON: %w", err)
		}
		body["runtime_config"] = rc
	}
	if cmd.Flags().Changed("custom-args") {
		v, _ := cmd.Flags().GetString("custom-args")
		ca, err := parseCustomArgs(v)
		if err != nil {
			return err
		}
		body["custom_args"] = ca
	}
	if ce, ok, err := resolveCustomEnv(cmd); err != nil {
		return err
	} else if ok {
		body["custom_env"] = ce
	}
	if mc, ok, err := resolveMcpConfig(cmd); err != nil {
		return err
	} else if ok {
		body["mcp_config"] = mc
	}
	if cmd.Flags().Changed("model") {
		v, _ := cmd.Flags().GetString("model")
		body["model"] = v
	}
	// thinking_level mirrors model: a thin pass-through to the top-level agent
	// field the server already accepts and validates (IsKnownThinkingValue).
	// The CLI deliberately does not enumerate valid levels — they are
	// runtime/model-specific and the server owns the catalog (MUL-2339).
	if cmd.Flags().Changed("thinking-level") {
		v, _ := cmd.Flags().GetString("thinking-level")
		body["thinking_level"] = v
	}
	if cmd.Flags().Changed("service-tier") {
		v, _ := cmd.Flags().GetString("service-tier")
		body["service_tier"] = v
	}
	if cmd.Flags().Changed("routing-tier") {
		v, _ := cmd.Flags().GetString("routing-tier")
		body["routing_tier"] = v
	}
	if cmd.Flags().Changed("visibility") {
		v, _ := cmd.Flags().GetString("visibility")
		body["visibility"] = v
	}
	applyAgentPermissionFlags(cmd, body)
	if cmd.Flags().Changed("max-concurrent-tasks") {
		v, _ := cmd.Flags().GetInt32("max-concurrent-tasks")
		if err := validateAgentMaxConcurrentTasksFlag(v); err != nil {
			return err
		}
		body["max_concurrent_tasks"] = v
	}
	// Two-level specialisation (DENE-301). An empty value means "independent
	// base role", which is also what omitting the flag means, so the key is
	// only sent when it carries an id.
	if parentAgentID != "" {
		body["parent_agent_id"] = parentAgentID
	}
	if domain != "" {
		body["domain_id"] = domain
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result map[string]any
	if err := client.PostJSON(ctx, "/api/agents", body, &result); err != nil {
		return fmt.Errorf("create agent: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, result)
	}

	fmt.Printf("Agent created: %s (%s)\n", strVal(result, "name"), strVal(result, "id"))
	return nil
}

func runAgentUpdate(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	body := map[string]any{}
	if cmd.Flags().Changed("name") {
		v, _ := cmd.Flags().GetString("name")
		body["name"] = v
	}
	if cmd.Flags().Changed("description") {
		v, _ := cmd.Flags().GetString("description")
		body["description"] = v
	}
	if cmd.Flags().Changed("instructions") {
		v, _ := cmd.Flags().GetString("instructions")
		body["instructions"] = v
	}
	if err := applyConversationStartersFlag(cmd, body); err != nil {
		return err
	}
	if cmd.Flags().Changed("runtime-id") {
		v, _ := cmd.Flags().GetString("runtime-id")
		body["runtime_id"] = v
	}
	if cmd.Flags().Changed("runtime-config") {
		v, _ := cmd.Flags().GetString("runtime-config")
		var rc any
		if err := json.Unmarshal([]byte(v), &rc); err != nil {
			return fmt.Errorf("--runtime-config must be valid JSON: %w", err)
		}
		body["runtime_config"] = rc
	}
	if cmd.Flags().Changed("custom-args") {
		v, _ := cmd.Flags().GetString("custom-args")
		ca, err := parseCustomArgs(v)
		if err != nil {
			return err
		}
		body["custom_args"] = ca
	}
	if cmd.Flags().Changed("model") {
		v, _ := cmd.Flags().GetString("model")
		body["model"] = v
	}
	// thinking_level is a tri-state on the server (omitted = no change, "" =
	// clear to runtime default, value = set). Sending the key only when the
	// flag was provided produces exactly that, the same way --model behaves.
	if cmd.Flags().Changed("thinking-level") {
		v, _ := cmd.Flags().GetString("thinking-level")
		body["thinking_level"] = v
	}
	if cmd.Flags().Changed("service-tier") {
		v, _ := cmd.Flags().GetString("service-tier")
		body["service_tier"] = v
	}
	if cmd.Flags().Changed("routing-tier") {
		v, _ := cmd.Flags().GetString("routing-tier")
		body["routing_tier"] = v
	}
	if cmd.Flags().Changed("dispatch-mode") {
		v, _ := cmd.Flags().GetString("dispatch-mode")
		body["dispatch_mode"] = v
	}
	if cmd.Flags().Changed("routing-usage") {
		v, _ := cmd.Flags().GetString("routing-usage")
		body["routing_usage"] = v
	}
	if cmd.Flags().Changed("dispatch-projects") {
		v, _ := cmd.Flags().GetString("dispatch-projects")
		ids, err := resolveDispatchProjects(client, v)
		if err != nil {
			return err
		}
		body["dispatch_projects"] = ids
	}
	if cmd.Flags().Changed("visibility") {
		v, _ := cmd.Flags().GetString("visibility")
		body["visibility"] = v
	}
	applyAgentPermissionFlags(cmd, body)
	if cmd.Flags().Changed("status") {
		v, _ := cmd.Flags().GetString("status")
		body["status"] = v
	}
	if cmd.Flags().Changed("max-concurrent-tasks") {
		v, _ := cmd.Flags().GetInt32("max-concurrent-tasks")
		if err := validateAgentMaxConcurrentTasksFlag(v); err != nil {
			return err
		}
		body["max_concurrent_tasks"] = v
	}
	if mc, ok, err := resolveMcpConfig(cmd); err != nil {
		return err
	} else if ok {
		body["mcp_config"] = mc
	}
	// parent_agent_id is a tri-state on the server, keyed on the field being
	// PRESENT in the body: absent = no change, "" = detach, id = attach. The
	// flag reproduces exactly that, so `--parent-agent-id ""` is a detach and
	// not a no-op (DENE-300 follow-up).
	if cmd.Flags().Changed("parent-agent-id") {
		v, _ := cmd.Flags().GetString("parent-agent-id")
		body["parent_agent_id"] = strings.TrimSpace(v)
	}

	// runtime_inherited (DENE-505) is an explicit switch in both directions, so
	// the key is sent whenever the flag was set — including `false`, which is the
	// opt-out and would otherwise be indistinguishable from "leave it alone".
	if cmd.Flags().Changed("runtime-inherited") {
		v, _ := cmd.Flags().GetBool("runtime-inherited")
		body["runtime_inherited"] = v
	}

	// work_enabled (DENE-714) is the reversible seat gate; like
	// runtime_inherited, `false` must reach the server, so key on Changed.
	if cmd.Flags().Changed("work-enabled") {
		v, _ := cmd.Flags().GetBool("work-enabled")
		body["work_enabled"] = v
	}

	if len(body) == 0 {
		return fmt.Errorf("no fields to update; use --name, --description, --instructions, --conversation-starters, --runtime-id, --runtime-config, --model, --thinking-level, --service-tier, --routing-tier, --routing-usage, --dispatch-mode, --dispatch-projects, --custom-args, --mcp-config, --visibility, --status, --max-concurrent-tasks, --parent-agent-id, --runtime-inherited, or --work-enabled (env vars now live behind `multica agent env set <id>`)")
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result map[string]any
	if err := client.PutJSON(ctx, "/api/agents/"+args[0], body, &result); err != nil {
		return fmt.Errorf("update agent: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, result)
	}

	fmt.Printf("Agent updated: %s (%s)\n", strVal(result, "name"), strVal(result, "id"))
	return nil
}

func runAgentArchive(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result map[string]any
	if err := client.PostJSON(ctx, "/api/agents/"+args[0]+"/archive", nil, &result); err != nil {
		return fmt.Errorf("archive agent: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, result)
	}

	fmt.Printf("Agent archived: %s (%s)\n", strVal(result, "name"), strVal(result, "id"))
	return nil
}

func runAgentSolidify(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result map[string]any
	if err := client.PostJSON(ctx, "/api/agents/"+args[0]+"/solidify", nil, &result); err != nil {
		return fmt.Errorf("solidify agent: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, result)
	}

	fmt.Printf("Agent solidified and detached: %s (%s)\n", strVal(result, "name"), strVal(result, "id"))
	return nil
}

func runAgentRestore(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result map[string]any
	if err := client.PostJSON(ctx, "/api/agents/"+args[0]+"/restore", nil, &result); err != nil {
		return fmt.Errorf("restore agent: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, result)
	}

	fmt.Printf("Agent restored: %s (%s)\n", strVal(result, "name"), strVal(result, "id"))
	return nil
}

func runAgentTasks(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	output, _ := cmd.Flags().GetString("output")
	params := url.Values{}
	limit, _ := cmd.Flags().GetInt("limit")
	if limit < 1 {
		return fmt.Errorf("limit must be a positive integer")
	}
	params.Set("limit", fmt.Sprint(limit))
	before, _ := cmd.Flags().GetString("before")
	if before != "" {
		params.Set("before", before)
	}
	if output == "json" {
		params.Set("include_usage", "true")
	}
	path := "/api/agents/" + args[0] + "/tasks?" + params.Encode()

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var tasks []map[string]any
	responseHeaders, err := client.GetJSONWithHeaders(ctx, path, &tasks)
	if err != nil {
		return fmt.Errorf("list agent runs: %w", err)
	}
	if cursor := responseHeaders.Get("X-Agent-Tasks-Next-Cursor"); cursor != "" {
		fmt.Fprintf(cmd.ErrOrStderr(), "More runs available; use --before %q to fetch the next page.\n", cursor)
	}

	if output == "json" {
		return cli.PrintJSON(os.Stdout, tasks)
	}

	headers := []string{"ID", "ISSUE_ID", "STATUS", "CREATED_AT"}
	rows := make([][]string, 0, len(tasks))
	for _, t := range tasks {
		rows = append(rows, []string{
			strVal(t, "id"),
			strVal(t, "issue_id"),
			strVal(t, "status"),
			strVal(t, "created_at"),
		})
	}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

func runAgentChats(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}
	limit, _ := cmd.Flags().GetInt("limit")
	if limit < 1 {
		return fmt.Errorf("limit must be a positive integer")
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	agentID, err := resolveAgent(ctx, client, args[0])
	if err != nil {
		return err
	}
	var resp struct {
		Chats   []map[string]any `json:"chats"`
		HasMore bool             `json:"has_more"`
	}
	path := "/api/agents/" + agentID + "/chats?" + url.Values{"limit": {fmt.Sprint(limit)}}.Encode()
	if err := client.GetJSON(ctx, path, &resp); err != nil {
		return fmt.Errorf("list agent chats: %w", err)
	}
	if resp.HasMore {
		fmt.Fprintln(cmd.ErrOrStderr(), "More chats available; raise --limit to see them.")
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, resp)
	}

	headers := []string{"ID", "STATUS", "LAST_ACTIVITY", "CREATOR_ID", "TITLE"}
	rows := make([][]string, 0, len(resp.Chats))
	for _, c := range resp.Chats {
		title := strVal(c, "title")
		if visible, _ := c["visible"].(bool); !visible {
			title = "(someone else's chat)"
		}
		rows = append(rows, []string{
			strVal(c, "id"),
			strVal(c, "status"),
			strVal(c, "last_activity_at"),
			strVal(c, "creator_id"),
			title,
		})
	}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

func runAgentAvatar(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	filePath, _ := cmd.Flags().GetString("file")
	if filePath == "" {
		return fmt.Errorf("--file is required")
	}

	// Validate file exists.
	info, err := os.Stat(filePath)
	if err != nil {
		return fmt.Errorf("file not found: %w", err)
	}

	// Validate extension.
	ext := strings.ToLower(filepath.Ext(filePath))
	validExts := map[string]bool{".png": true, ".jpg": true, ".jpeg": true, ".gif": true, ".webp": true}
	if !validExts[ext] {
		return fmt.Errorf("unsupported file format %q: must be .png, .jpg, .jpeg, .gif, or .webp", ext)
	}

	// Client-side size guard: reject files > 5MB.
	const maxSize = 5 << 20 // 5 MB
	if info.Size() > maxSize {
		return fmt.Errorf("file too large: %d bytes (max 5MB)", info.Size())
	}

	fileData, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("read file: %w", err)
	}

	// Defensive re-check: guard against TOCTOU race where the file
	// was swapped between stat and read.
	if len(fileData) > maxSize {
		return fmt.Errorf("file too large: %d bytes (max 5MB)", len(fileData))
	}

	ctx, cancel := context.WithTimeout(context.Background(), cli.AtLeastAPITimeout(60*time.Second))
	defer cancel()

	// Agent existence pre-check.
	var agent map[string]any
	if err := client.GetJSON(ctx, "/api/agents/"+args[0], &agent); err != nil {
		return fmt.Errorf("get agent: %w", err)
	}

	id, url, err := client.UploadFileWithURL(ctx, fileData, filePath)
	if err != nil {
		return fmt.Errorf("upload avatar: %w", err)
	}

	body := map[string]any{"avatar_url": url}
	var result map[string]any
	if err := client.PutJSON(ctx, "/api/agents/"+args[0], body, &result); err != nil {
		return fmt.Errorf("update agent avatar: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, map[string]any{
			"id":         id,
			"agent_id":   args[0],
			"avatar_url": url,
		})
	}

	headers := []string{"ID", "AGENT_ID", "AVATAR_URL"}
	rows := [][]string{{
		id,
		args[0],
		url,
	}}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

// ---------------------------------------------------------------------------
// Agent skills subcommands
// ---------------------------------------------------------------------------

func runAgentSkillsList(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var skills []map[string]any
	if err := client.GetJSON(ctx, "/api/agents/"+args[0]+"/skills", &skills); err != nil {
		return fmt.Errorf("list agent skills: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, skills)
	}

	headers := []string{"ID", "NAME", "DESCRIPTION"}
	rows := make([][]string, 0, len(skills))
	for _, s := range skills {
		rows = append(rows, []string{
			strVal(s, "id"),
			strVal(s, "name"),
			strVal(s, "description"),
		})
	}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

func runAgentSkillsSet(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	if !cmd.Flags().Changed("skill-ids") {
		return fmt.Errorf("--skill-ids is required (comma-separated skill IDs; use --skill-ids '' to clear all)")
	}
	cleanIDs := cleanSkillIDsFlag(cmd)
	body := map[string]any{
		"skill_ids": cleanIDs,
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result json.RawMessage
	if err := client.PutJSON(ctx, "/api/agents/"+args[0]+"/skills", body, &result); err != nil {
		return fmt.Errorf("set agent skills: %w", err)
	}

	return printAgentSkillsMutationResult(cmd, args[0], result)
}

func runAgentSkillsAdd(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	if !cmd.Flags().Changed("skill-ids") {
		return fmt.Errorf("--skill-ids is required (comma-separated skill IDs)")
	}
	cleanIDs := cleanSkillIDsFlag(cmd)
	if len(cleanIDs) == 0 {
		return fmt.Errorf("--skill-ids must include at least one skill ID")
	}
	body := map[string]any{
		"skill_ids": cleanIDs,
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result json.RawMessage
	if err := client.PostJSON(ctx, "/api/agents/"+args[0]+"/skills/add", body, &result); err != nil {
		return fmt.Errorf("add agent skills: %w", err)
	}

	return printAgentSkillsMutationResult(cmd, args[0], result)
}

func cleanSkillIDsFlag(cmd *cobra.Command) []string {
	skillIDs, _ := cmd.Flags().GetStringSlice("skill-ids")
	cleanIDs := make([]string, 0, len(skillIDs))
	for _, id := range skillIDs {
		id = strings.TrimSpace(id)
		if id != "" {
			cleanIDs = append(cleanIDs, id)
		}
	}
	return cleanIDs
}

func printAgentSkillsMutationResult(cmd *cobra.Command, agentID string, result json.RawMessage) error {
	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		var pretty any
		json.Unmarshal(result, &pretty)
		return cli.PrintJSON(os.Stdout, pretty)
	}

	var skills []map[string]any
	if err := json.Unmarshal(result, &skills); err != nil {
		return fmt.Errorf("decode agent skills response: %w", err)
	}
	if len(skills) == 0 {
		fmt.Printf("No skills assigned to agent %s\n", agentID)
		return nil
	}
	headers := []string{"ID", "NAME", "DESCRIPTION"}
	rows := make([][]string, 0, len(skills))
	for _, s := range skills {
		rows = append(rows, []string{
			strVal(s, "id"),
			strVal(s, "name"),
			strVal(s, "description"),
		})
	}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

// ---------------------------------------------------------------------------
// Agent env subcommands
// ---------------------------------------------------------------------------

// runAgentEnvGet fetches the plaintext custom_env for a single agent
// via the audited `/env` endpoint. The CLI prints raw JSON in JSON
// mode and a key/value table otherwise; we never truncate or mask
// values here — the security gate is on the server, not the printer.
func runAgentEnvGet(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var resp map[string]any
	if err := client.GetJSON(ctx, "/api/agents/"+args[0]+"/env", &resp); err != nil {
		return fmt.Errorf("get agent env: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, resp)
	}

	headers := []string{"KEY", "VALUE"}
	env, _ := resp["custom_env"].(map[string]any)
	rows := make([][]string, 0, len(env))
	for k, v := range env {
		rows = append(rows, []string{k, fmt.Sprintf("%v", v)})
	}
	cli.PrintTable(os.Stdout, headers, rows)
	return nil
}

// runAgentEnvSet replaces an agent's custom_env wholesale via the
// audited `/env` endpoint. The three secret-safe input channels
// (--custom-env, --custom-env-stdin, --custom-env-file) are required
// — at least one must be supplied — and the server treats any value
// equal to "****" as "preserve the existing entry" (see the **** guard
// in the handler).
func runAgentEnvSet(cmd *cobra.Command, args []string) error {
	client, err := newAPIClient(cmd)
	if err != nil {
		return err
	}

	ce, ok, err := resolveCustomEnv(cmd)
	if err != nil {
		return err
	}
	if !ok {
		return fmt.Errorf("specify the new env via --custom-env, --custom-env-stdin, or --custom-env-file (pass '{}' to clear)")
	}

	body := map[string]any{"custom_env": ce}

	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()

	var result map[string]any
	if err := client.PutJSON(ctx, "/api/agents/"+args[0]+"/env", body, &result); err != nil {
		return fmt.Errorf("update agent env: %w", err)
	}

	output, _ := cmd.Flags().GetString("output")
	if output == "json" {
		return cli.PrintJSON(os.Stdout, result)
	}

	env, _ := result["custom_env"].(map[string]any)
	fmt.Printf("Env updated for agent %s (%d keys)\n", args[0], len(env))
	return nil
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// parseCustomEnv parses the --custom-env flag value (a JSON object literal)
// into a string map suitable for the request body. The clear-all signal is
// the explicit JSON object "{}"; empty or whitespace-only input is rejected
// because for the stdin/file channels it almost always means an upstream
// failure (missing file, unset pipe, set -o pipefail off) rather than a
// deliberate clear. Treating it as "clear" silently wipes secrets.
//
// The payload is treated as secret material: parse errors never wrap the
// underlying json error, because json.SyntaxError / UnmarshalTypeError can
// surface short fragments of the input on some malformed inputs.
func parseCustomEnv(raw string) (map[string]string, error) {
	if strings.TrimSpace(raw) == "" {
		return nil, fmt.Errorf("--custom-env: empty input; pass '{}' to clear")
	}
	var ce map[string]string
	if err := json.Unmarshal([]byte(raw), &ce); err != nil {
		return nil, fmt.Errorf("--custom-env must be a valid JSON object of string keys and string values")
	}
	if ce == nil {
		ce = map[string]string{}
	}
	return ce, nil
}

// parseCustomArgs parses the --custom-args flag value (a JSON array of
// CLI argument strings). The error message is content-free for the same
// reason as parseCustomEnv: although custom_args is not a dedicated
// secret channel today, it routinely carries values like "--api-key=…"
// for runtime providers, and json.Unmarshal errors can echo short
// fragments of malformed input.
func parseCustomArgs(raw string) ([]string, error) {
	var ca []string
	if err := json.Unmarshal([]byte(raw), &ca); err != nil {
		return nil, fmt.Errorf("--custom-args must be a valid JSON array of strings")
	}
	return ca, nil
}

// agentConversationStarter is the CLI wire shape for conversation_starters.
// Limits match the server/handler and packages/core/agents/constants.ts.
type agentConversationStarter struct {
	Label  string `json:"label"`
	Prompt string `json:"prompt"`
}

func applyConversationStartersFlag(cmd *cobra.Command, body map[string]any) error {
	if !cmd.Flags().Changed("conversation-starters") {
		return nil
	}
	v, _ := cmd.Flags().GetString("conversation-starters")
	starters, err := parseConversationStarters(v)
	if err != nil {
		return err
	}
	body["conversation_starters"] = starters
	return nil
}

// parseConversationStarters parses --conversation-starters (a JSON array of
// {label, prompt} objects). An explicit [] is a valid clear; null/empty input
// is rejected so it cannot be confused with omit. A nil slice is coerced to
// empty so encoding/json emits [] rather than null.
func parseConversationStarters(raw string) ([]agentConversationStarter, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" || strings.EqualFold(trimmed, "null") {
		return nil, fmt.Errorf("--conversation-starters must be a JSON array of {\"label\",\"prompt\"} objects; pass '[]' to clear")
	}
	var starters []agentConversationStarter
	if err := json.Unmarshal([]byte(raw), &starters); err != nil {
		return nil, fmt.Errorf("--conversation-starters must be a JSON array of {\"label\",\"prompt\"} objects")
	}
	if starters == nil {
		starters = []agentConversationStarter{}
	}
	if len(starters) > 3 {
		return nil, fmt.Errorf("--conversation-starters must contain at most 3 items")
	}
	return starters, nil
}

// resolveCustomEnv collects the --custom-env, --custom-env-stdin, and
// --custom-env-file flags and returns the parsed map, a bool indicating
// whether the caller supplied any of them, and any error. The three input
// channels are mutually exclusive so callers can't accidentally provide a
// secret twice. Stdin and file inputs exist to keep secret material out of
// shell history and 'ps' / /proc/<pid>/cmdline.
func resolveCustomEnv(cmd *cobra.Command) (map[string]string, bool, error) {
	inline := cmd.Flags().Changed("custom-env")
	fromStdin, _ := cmd.Flags().GetBool("custom-env-stdin")
	filePath, _ := cmd.Flags().GetString("custom-env-file")
	// Note: an explicit --custom-env-file "" is honored as "the user asked
	// for this channel with an empty path" and surfaces a real error below,
	// rather than being silently swallowed.
	fromFile := cmd.Flags().Changed("custom-env-file")

	count := 0
	if inline {
		count++
	}
	if fromStdin {
		count++
	}
	if fromFile {
		count++
	}
	switch {
	case count == 0:
		return nil, false, nil
	case count > 1:
		return nil, false, fmt.Errorf("--custom-env, --custom-env-stdin, and --custom-env-file are mutually exclusive; pick one")
	}

	var raw string
	switch {
	case inline:
		raw, _ = cmd.Flags().GetString("custom-env")
	case fromStdin:
		buf, err := io.ReadAll(cmd.InOrStdin())
		if err != nil {
			return nil, false, fmt.Errorf("read --custom-env-stdin: %w", err)
		}
		raw = string(buf)
		if strings.TrimSpace(raw) == "" {
			return nil, false, fmt.Errorf("--custom-env-stdin: empty input; pass '{}' to clear")
		}
	case fromFile:
		if filePath == "" {
			return nil, false, fmt.Errorf("--custom-env-file: path must not be empty")
		}
		buf, err := os.ReadFile(filePath)
		if err != nil {
			// Filesystem errors may include the path but not the contents —
			// safe to surface via %w.
			return nil, false, fmt.Errorf("read --custom-env-file: %w", err)
		}
		raw = string(buf)
		if strings.TrimSpace(raw) == "" {
			return nil, false, fmt.Errorf("--custom-env-file %q: empty contents; pass '{}' to clear", filePath)
		}
	}

	ce, err := parseCustomEnv(raw)
	if err != nil {
		return nil, false, err
	}
	return ce, true, nil
}

// parseMcpConfig validates the --mcp-config value and returns the raw JSON to
// send. It accepts a JSON object (the MCP config, e.g. {"mcpServers": {…}}) or
// the literal `null` to clear the agent's config.
func parseMcpConfig(raw string) (json.RawMessage, error) {
	return parseMcpJSONObject("--mcp-config", raw, true)
}

// parseMcpJSONObject validates a JSON-object payload supplied through one of
// the secret-safe flag channels. A top-level array or primitive is rejected
// because it can never be a valid MCP payload — this mirrors the agent-settings
// UI (mcp-config-tab.tsx). Empty/whitespace input is rejected rather than
// treated as a clear: for the stdin/file channels it almost always signals an
// upstream failure (missing file, unset pipe) rather than a deliberate clear,
// and silently wiping a secret-bearing field is the wrong default.
//
// allowNull controls whether the literal `null` is accepted as the clear
// sentinel. It is not for a single server entry, where removing something has
// its own command and `null` is far more likely to be a mistake.
//
// The payload is treated as secret material (MCP entries routinely carry API
// tokens), so parse errors never wrap the underlying json error, which can
// echo short fragments of malformed input.
func parseMcpJSONObject(flag, raw string, allowNull bool) (json.RawMessage, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		if allowNull {
			return nil, fmt.Errorf("%s: empty input; pass 'null' to clear or a JSON object to set", flag)
		}
		return nil, fmt.Errorf("%s: empty input; pass a JSON object", flag)
	}
	var probe any
	if err := json.Unmarshal([]byte(trimmed), &probe); err != nil {
		if allowNull {
			return nil, fmt.Errorf("%s must be a valid JSON object, or 'null' to clear", flag)
		}
		return nil, fmt.Errorf("%s must be a valid JSON object", flag)
	}
	if probe == nil {
		if allowNull {
			// null → clear (NULL column server-side; on create it is a no-op).
			return json.RawMessage("null"), nil
		}
		return nil, fmt.Errorf("%s must be a JSON object, not null", flag)
	}
	if _, ok := probe.(map[string]any); !ok {
		if allowNull {
			return nil, fmt.Errorf("%s must be a JSON object, or 'null' to clear", flag)
		}
		return nil, fmt.Errorf("%s must be a JSON object", flag)
	}
	return json.RawMessage(trimmed), nil
}

// resolveMcpConfig collects the --mcp-config, --mcp-config-stdin, and
// --mcp-config-file flags and returns the raw JSON value to send, a bool
// indicating whether the caller supplied any of them, and any error. Mirrors
// resolveCustomEnv; the only behavioural difference is the clear sentinel
// (`null` here vs `{}` for custom_env), because mcp_config distinguishes an
// explicit empty object from an absent config server-side.
func resolveMcpConfig(cmd *cobra.Command) (json.RawMessage, bool, error) {
	return resolveMcpJSONObject(cmd, "mcp-config", true)
}

// resolveMcpJSONObject collects the `<prefix>`, `<prefix>-stdin`, and
// `<prefix>-file` flags. The three input channels are mutually exclusive so
// callers can't accidentally provide a secret twice. Stdin and file inputs
// exist to keep payloads — which routinely embed API tokens — out of shell
// history and 'ps'.
func resolveMcpJSONObject(cmd *cobra.Command, prefix string, allowNull bool) (json.RawMessage, bool, error) {
	inline := cmd.Flags().Changed(prefix)
	fromStdin, _ := cmd.Flags().GetBool(prefix + "-stdin")
	filePath, _ := cmd.Flags().GetString(prefix + "-file")
	fromFile := cmd.Flags().Changed(prefix + "-file")

	count := 0
	if inline {
		count++
	}
	if fromStdin {
		count++
	}
	if fromFile {
		count++
	}
	switch {
	case count == 0:
		return nil, false, nil
	case count > 1:
		return nil, false, fmt.Errorf("--%s, --%s-stdin, and --%s-file are mutually exclusive; pick one", prefix, prefix, prefix)
	}

	clearHint := ""
	if allowNull {
		clearHint = "; pass 'null' to clear"
	}
	var raw string
	switch {
	case inline:
		raw, _ = cmd.Flags().GetString(prefix)
	case fromStdin:
		buf, err := io.ReadAll(cmd.InOrStdin())
		if err != nil {
			return nil, false, fmt.Errorf("read --%s-stdin: %w", prefix, err)
		}
		raw = string(buf)
		if strings.TrimSpace(raw) == "" {
			return nil, false, fmt.Errorf("--%s-stdin: empty input%s", prefix, clearHint)
		}
	case fromFile:
		if filePath == "" {
			return nil, false, fmt.Errorf("--%s-file: path must not be empty", prefix)
		}
		buf, err := os.ReadFile(filePath)
		if err != nil {
			// Filesystem errors may include the path but not the contents —
			// safe to surface via %w.
			return nil, false, fmt.Errorf("read --%s-file: %w", prefix, err)
		}
		raw = string(buf)
		if strings.TrimSpace(raw) == "" {
			return nil, false, fmt.Errorf("--%s-file %q: empty contents%s", prefix, filePath, clearHint)
		}
	}

	mc, err := parseMcpJSONObject("--"+prefix, raw, allowNull)
	if err != nil {
		return nil, false, err
	}
	return mc, true, nil
}

func strVal(m map[string]any, key string) string {
	v, ok := m[key]
	if !ok || v == nil {
		return ""
	}
	return fmt.Sprintf("%v", v)
}

// resolveDispatchProjects turns --dispatch-projects into project ids. An empty
// value is an empty list, which lifts the limit. An entry matching a project
// title exactly wins over id-prefix matching.
func resolveDispatchProjects(client *cli.APIClient, raw string) ([]string, error) {
	ids := []string{}
	if strings.TrimSpace(raw) == "" {
		return ids, nil
	}
	ctx, cancel := cli.APIContext(context.Background())
	defer cancel()
	projects, err := fetchProjectCandidates(ctx, client)
	if err != nil {
		return nil, fmt.Errorf("list projects: %w", err)
	}
	for _, entry := range strings.Split(raw, ",") {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		id := ""
		for _, p := range projects {
			if p.Display == entry {
				id = p.ID
				break
			}
		}
		if id == "" {
			resolved, err := resolveProjectID(ctx, client, entry)
			if err != nil {
				return nil, fmt.Errorf("--dispatch-projects %q: %w", entry, err)
			}
			id = resolved.ID
		}
		ids = append(ids, id)
	}
	return ids, nil
}
