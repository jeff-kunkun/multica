#!/usr/bin/env python3
"""Multica -> Grok execution mailbox.

Bot-initiated Multica operations use the cloud computer's direct CLI login.
This Mac-side bridge only dispatches execution tasks and accepts their results.
The mailbox is no longer an alternative permissions or query interface.
"""
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))

# The whitelist. Anything not listed here is rejected and audited.
ALLOWED_ACTIONS = ("task_result",)

ISSUE_RE = re.compile(r"^[A-Z][A-Z0-9]{1,9}-\d{1,6}$")
FILE_RE = re.compile(r"^[A-Za-z0-9._-]{1,96}\.json$")
ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,96}$")
MAX_FILE_BYTES = 32 * 1024
MAX_TEXT = 4000

DEFAULTS = {
    "ssh": ["ssh", "-F", "~/.grok-mailbox/ssh_config", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20", "-o", "ForwardAgent=no",
            "-o", "ControlMaster=no", "-o", "ControlPath=none", "-o", "ServerAliveInterval=10", "-o", "ServerAliveCountMax=3", "grok-bot"],
    # /workspace is the only directory Grok keeps across resets.
    "remote_root": "/workspace/mailbox",
    "state_dir": "~/.grok-mailbox",
    "multica": "multica",
    # Issue prefixes Grok Bot may touch.
    "issue_prefixes": ["DENE"],
    "limits": {"per_poll": 10, "create_per_day": 5, "comment_per_day": 30},
    "watch_hours": 24,
    "active_interval": 3,
    "active_seconds": 300,
}


def now():
    return dt.datetime.now(dt.timezone.utc)


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def load_config(path):
    cfg = json.loads(json.dumps(DEFAULTS))
    if path:
        with open(os.path.expanduser(path), encoding="utf-8") as f:
            user = json.load(f)
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    cfg["state_dir"] = os.path.expanduser(cfg["state_dir"])
    os.makedirs(os.path.join(cfg["state_dir"], "tmp"), exist_ok=True)
    return cfg


class State:
    """Local bridge memory: processed messages, tasks we issued, issues we watch."""

    def __init__(self, cfg):
        self.path = os.path.join(cfg["state_dir"], "state.json")
        self.audit_path = os.path.join(cfg["state_dir"], "audit.jsonl")
        try:
            with open(self.path, encoding="utf-8") as f:
                self.data = json.load(f)
        except FileNotFoundError:
            self.data = {}
        for k in ("seen", "tasks", "watch", "own_comments", "counters", "outq"):
            self.data.setdefault(k, [] if k in ("own_comments", "outq") else {})

    def queue(self, msg):
        """Park a message for the bot's inbox; flush() delivers it."""
        name = f"{int(time.time() * 1000)}-{msg['type']}-{uuid.uuid4().hex[:6]}.json"
        self.data["outq"].append({"name": name, "msg": msg})
        self.save()
        return name

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def audit(self, **rec):
        rec = {"ts": iso(now()), **rec}
        with open(self.audit_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def bump(self, kind, limit):
        day = now().strftime("%Y-%m-%d")
        key = f"{day}:{kind}"
        self.data["counters"] = {k: v for k, v in self.data["counters"].items() if k.startswith(day)}
        n = self.data["counters"].get(key, 0)
        if n >= limit:
            return False
        self.data["counters"][key] = n + 1
        return True

    def unbump(self, kind):
        """A failed Multica call is retried next poll; it must not eat the quota."""
        key = f"{now().strftime('%Y-%m-%d')}:{kind}"
        if self.data["counters"].get(key):
            self.data["counters"][key] -= 1


class Rejected(Exception):
    pass


# ---------------------------------------------------------------- transport

PULL_SCRIPT = r"""
set -eu
root=$1
mkdir -p "$root/outbox" "$root/inbox" "$root/processed"
for f in "$root"/outbox/*.json; do
  [ -f "$f" ] || continue
  printf '%s %s\n' "$(basename "$f")" "$(head -c 40000 "$f" | base64 | tr -d '\n')"
done
"""

ACK_SCRIPT = r"""
set -eu
root=$1; shift
for n in "$@"; do
  [ -f "$root/outbox/$n" ] && mv -f "$root/outbox/$n" "$root/processed/$n"
done
true
"""

WRITE_SCRIPT = r"""
set -eu
root=$1; name=$2
mkdir -p "$root/inbox"
cat > "$root/inbox/.$name.part"
mv -f "$root/inbox/.$name.part" "$root/inbox/$name"
"""


class Remote:
    def __init__(self, cfg):
        self.ssh = [os.path.expanduser(a) if a.startswith("~/") else a for a in cfg["ssh"]]
        self.root = cfg["remote_root"]

    def _sh(self, script, args, stdin=b""):
        # The script travels as one fixed string; every argument is quoted and
        # file names were validated by FILE_RE before they reach this point.
        argv = " ".join(shlex.quote(a) for a in [self.root] + args)
        cmd = self.ssh + [f"sh -c {shlex.quote(script)} mailbox {argv}"]
        # 255 = ssh itself failed (the DERP-relayed link drops now and then);
        # every script here is safe to repeat, so retry once.
        for attempt in (1, 2):
            try:
                p = subprocess.run(cmd, input=stdin, capture_output=True, timeout=60)
            except subprocess.TimeoutExpired:
                p = subprocess.CompletedProcess(cmd, 255, b"", b"ssh timed out after 60s")
            if p.returncode != 255 or attempt == 2:
                break
            time.sleep(5)
        if p.returncode != 0:
            raise RuntimeError(f"ssh failed ({p.returncode}): {p.stderr.decode(errors='replace').strip()[:400]}")
        return p.stdout.decode()

    def pull(self):
        out = []
        for line in self._sh(PULL_SCRIPT, []).splitlines():
            name, _, b64 = line.partition(" ")
            out.append((name, base64.b64decode(b64) if b64 else b""))
        return out

    def ack(self, names):
        if names:
            self._sh(ACK_SCRIPT, names)

    def write(self, name, msg):
        self._sh(WRITE_SCRIPT, [name], json.dumps(msg, ensure_ascii=False, indent=1).encode())


def flush(st, rm):
    """Deliver queued inbox messages in order; on a transport failure keep the
    rest for the next poll so an action already done in Multica never loses
    its reply."""
    sent = 0
    while st.data["outq"]:
        item = st.data["outq"][0]
        try:
            rm.write(item["name"], item["msg"])
        except RuntimeError as e:
            st.audit(sender="bridge", action="deliver", file=item["name"], decision="error", reason=str(e)[:300])
            break
        st.data["outq"].pop(0)
        st.save()
        sent += 1
    return sent


# ---------------------------------------------------------------- multica

class Multica:
    def __init__(self, cfg, dry_run=False):
        self.bin = cfg["multica"]
        self.tmp = os.path.join(cfg["state_dir"], "tmp")
        self.dry = dry_run

    def run(self, args, write=False):
        if self.dry and write:
            return {"dry_run": [self.bin] + args}
        p = subprocess.run([self.bin] + args + ["--output", "json"], cwd=self.tmp,
                           capture_output=True, text=True, timeout=90)
        if p.returncode != 0:
            raise RuntimeError(f"multica {' '.join(args[:3])} failed: {p.stderr.strip()[:400]}")
        try:
            return json.loads(p.stdout) if p.stdout.strip() else {}
        except json.JSONDecodeError:
            raise RuntimeError("multica returned non-JSON output; check CLI version and command support")

    def body_file(self, text):
        name = f"body-{uuid.uuid4().hex[:8]}.md"
        with open(os.path.join(self.tmp, name), "w", encoding="utf-8") as f:
            f.write(text)
        return name

    def comment(self, issue, text):
        f = self.body_file(text)
        try:
            return self.run(["issue", "comment", "add", issue, "--content-file", f], write=True)
        finally:
            os.remove(os.path.join(self.tmp, f))

# ---------------------------------------------------------------- policy

def defang(text):
    """The bot's words are quoted, never executed: no platform mentions, bounded size."""
    text = str(text)[:MAX_TEXT]
    text = re.sub(r"mention://", "mention-blocked://", text, flags=re.I)
    return text


def quote_block(text):
    return "\n".join("> " + line for line in text.splitlines()) or "> （空）"


def check_issue(cfg, issue):
    if not isinstance(issue, str) or not ISSUE_RE.match(issue):
        raise Rejected(f"票号格式不对：{str(issue)[:40]!r}")
    if issue.split("-")[0] not in cfg["issue_prefixes"]:
        raise Rejected(f"不允许访问这个前缀的票：{issue}")
    return issue


def parse(raw, name):
    if len(raw) > MAX_FILE_BYTES:
        raise Rejected("消息太大")
    try:
        msg = json.loads(raw.decode("utf-8"))
    except Exception:
        raise Rejected("不是合法的 JSON")
    if not isinstance(msg, dict):
        raise Rejected("消息必须是 JSON 对象")
    mid = str(msg.get("id") or name.rsplit(".", 1)[0])
    if not ID_RE.match(mid):
        raise Rejected("id 格式不对")
    msg["id"] = mid
    return msg


def handle(cfg, st, mc, msg):
    """Perform one whitelisted action. Returns (multica_action, reply_for_bot)."""
    action = msg.get("action")
    if action not in ALLOWED_ACTIONS:
        raise Rejected(f"动作「{action}」不在白名单里（只允许：{'、'.join(ALLOWED_ACTIONS)}）")
    # task_result: only for a task id the bridge itself issued; the issue comes
    # from our own record, never from the bot.
    tid = msg.get("task")
    task = st.data["tasks"].get(tid) if isinstance(tid, str) else None
    if not task:
        raise Rejected(f"不认识的任务 id：{str(tid)[:40]!r}")
    if task.get("done"):
        raise Rejected(f"任务 {tid} 已经回报过")
    text = defang(msg.get("text", ""))
    code = msg.get("exit_code")
    body = (f"📮 **Grok Bot 回报任务结果**（任务 `{tid}`" + (f"，退出码 `{code}`" if isinstance(code, int) else "") +
            f"）\n\n交代的任务：\n{quote_block(task['instructions'])}\n\nGrok Bot 的回报（原话，未经核验）：\n```text\n"
            f"{text.replace('```', 'ʼʼʼ')}\n```\n")
    res = mc.comment(task["issue"], body)
    cid = res.get("id") if isinstance(res, dict) else None
    if cid:
        st.data["own_comments"] = (st.data["own_comments"] + [cid])[-500:]
    task["done"] = iso(now())
    return (f"task_result {tid} -> comment {task['issue']}",
            {"type": "ack", "re": msg["id"], "ok": True, "issue": task["issue"], "result": "任务结果已贴回 Multica"})


# ---------------------------------------------------------------- cycle

def poll(cfg, dry_run=False):
    st, rm, mc = State(cfg), Remote(cfg), Multica(cfg, dry_run)
    summary = {"processed": 0, "rejected": 0, "replies": 0}
    acked = []
    flush(st, rm)
    for name, raw in sorted(rm.pull())[: cfg["limits"]["per_poll"]]:
        digest = hashlib.sha256(raw).hexdigest()[:16]
        if not FILE_RE.match(name):
            st.audit(sender="grok", file=name[:100], sha=digest, decision="rejected", reason="文件名不合规（未移动）")
            summary["rejected"] += 1
            continue
        if st.data["seen"].get(name) == digest:
            acked.append(name)
            continue
        rec = {"sender": "grok", "transport": cfg["ssh"][-1], "file": name, "sha": digest}
        try:
            msg = parse(raw, name)
            rec.update(id=msg["id"], claimed_from=str(msg.get("from", ""))[:40], action=str(msg.get("action"))[:40])
            done, reply = handle(cfg, st, mc, msg)
            rec.update(decision="allowed", multica=done)
            summary["processed"] += 1
        except Rejected as e:
            reply = {"type": "rejected", "re": rec.get("id", name), "reason": str(e)}
            rec.update(decision="rejected", reason=str(e))
            summary["rejected"] += 1
        except Exception as e:  # Multica/transport failure: keep the file for the next poll
            rec.update(decision="error", reason=str(e)[:400])
            st.audit(**rec)
            st.save()
            continue
        if dry_run:
            rec["dry_run"] = True
        st.audit(**rec)
        st.data["seen"][name] = digest
        st.queue(reply)
        acked.append(name)
    st.data["seen"] = dict(list(st.data["seen"].items())[-2000:])
    st.save()
    flush(st, rm)
    summary["undelivered"] = len(st.data["outq"])
    rm.ack(acked)
    return summary


def cmd_task(cfg, args):
    st, rm = State(cfg), Remote(cfg)
    issue = check_issue(cfg, args.issue)
    tid = "t-" + uuid.uuid4().hex[:10]
    st.data["tasks"][tid] = {"issue": issue, "instructions": args.instructions, "created": iso(now())}
    msg = {"type": "task", "id": tid, "issue": issue, "instructions": args.instructions,
           "reply_with": {"action": "task_result", "task": tid, "text": "<命令输出或结果摘要>", "exit_code": 0}}
    name = st.queue(msg)
    st.audit(sender="bridge", action="task_out", id=tid, issue=issue, decision="queued", file=name)
    flush(st, rm)
    print(json.dumps({"task": tid, "inbox_file": name, "delivered": not st.data["outq"]}, ensure_ascii=False))


INSTALL_SCRIPT = r"""
set -eu
root=$1; name=$2
mkdir -p "$root/inbox" "$root/outbox" "$root/processed"
cat > "$root/$name"
chmod +x "$root/$name"
"""


def cmd_setup_bot(cfg):
    """Create the mailbox on Grok and copy the credential-free helpers there."""
    rm = Remote(cfg)
    for rel in ("bot/mbox.py", "bot/cred-scan.sh", "bot/standing-instructions.md", "bot/direct-check.py"):
        with open(os.path.join(HERE, rel), "rb") as f:
            rm._sh(INSTALL_SCRIPT, [os.path.basename(rel)], f.read())
    print(f"mailbox ready on {cfg['ssh'][-1]}:{cfg['remote_root']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=os.environ.get("GROK_MAILBOX_CONFIG"))
    ap.add_argument("--dry-run", action="store_true", help="don't write to Multica; still talks to Grok")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("poll")
    r = sub.add_parser("run")
    r.add_argument("--interval", type=int, default=60)
    t = sub.add_parser("task")
    t.add_argument("--issue", required=True)
    t.add_argument("--instructions", required=True)
    sub.add_parser("setup-bot")
    a = sub.add_parser("audit")
    a.add_argument("-n", type=int, default=20)
    args = ap.parse_args()
    cfg = load_config(args.config)

    if args.cmd == "poll":
        print(json.dumps(poll(cfg, args.dry_run), ensure_ascii=False))
    elif args.cmd == "run":
        active_until = 0.0
        while True:
            try:
                summary = poll(cfg, args.dry_run)
                if summary["processed"] or summary["rejected"] or summary["replies"]:
                    active_until = time.monotonic() + cfg["active_seconds"]
                print(iso(now()), json.dumps(summary, ensure_ascii=False), flush=True)
            except Exception as e:
                print(iso(now()), "poll error:", e, file=sys.stderr, flush=True)
            time.sleep(max(1, min(args.interval, cfg["active_interval"])) if time.monotonic() < active_until else max(1, args.interval))
    elif args.cmd == "setup-bot":
        cmd_setup_bot(cfg)
    elif args.cmd == "task":
        cmd_task(cfg, args)
    elif args.cmd == "audit":
        try:
            with open(State(cfg).audit_path, encoding="utf-8") as f:
                sys.stdout.writelines(f.readlines()[-args.n:])
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    main()
