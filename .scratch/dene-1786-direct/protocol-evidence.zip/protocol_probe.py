import importlib.util,json,sys,tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location("bridge",sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Client:
 def comment(self, issue, body): return {"id":"fixture-comment"}
with tempfile.TemporaryDirectory() as d:
 cfg=dict(m.DEFAULTS);cfg["state_dir"]=d
 st=m.State(cfg)
 try:
  _,reply=m.handle(cfg,st,Client(),{"id":"same-input","action":"comment","issue":"DENE-1786","text":"fixture only"})
  print(json.dumps({"action":"comment","accepted":reply["ok"]}))
 except m.Rejected as e:
  print("REJECTED: "+str(e));sys.exit(3)
