#!/usr/bin/env python3
"""Grok Bot <-> Multica mailbox bridge.

Runs on Kun's Mac (all credentials stay here). Over SSH (`ssh grok-bot`, the
Tailscale link from DENE-1763) it pulls /workspace/mailbox/outbox/*.json from
the Grok Bot cloud computer, checks each message against a fixed action
whitelist, performs the allowed Multica action with the local `multica` CLI,
and writes acks / replies / tasks into /workspace/mailbox/inbox. The Grok
computer never holds a Multica, model or GitHub credential (it is shared by all
of Kun's Grok bots); it only sees what the bridge writes into its inbox.

Every message, allowed or rejected, lands in <state>/audit.jsonl.

Subcommands:
  poll              one pull/act/push cycle
  run               poll forever (--interval seconds)
  task              our agent hands Grok Bot a task bound to an issue
  setup-bot         install the helper scripts into the mailbox on Grok
  audit             print the audit log tail
"""
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))

# The whitelist. Anything not listed here is rejected and audited.
ALLOWED_ACTIONS = ("comment", "create_issue", "status", "task_result", "query")

ISSUE_RE = re.compile(r"^[A-Z][A-Z0-9]{1,9}-\d{1,6}$")
FILE_RE = re.compile(r"^[A-Za-z0-9._-]{1,96}\.json$")
ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,96}$")
MAX_FILE_BYTES = 32 * 1024
MAX_TEXT = 4000
MAX_TITLE = 120

DEFAULTS = {
    "ssh": ["ssh", "-F", "~/.grok-mailbox/ssh_config", "-o", "BatchMode=yes", "-o", "ConnectTimeout=20", "-o", "ForwardAgent=no",
            "-o", "ControlMaster=no", "-o", "ControlPath=none", "-o", "ServerAliveInterval=10", "-o", "ServerAliveCountMax=3", "grok-bot"],
    # /workspace is the only directory Grok keeps across resets.
    "remote_root": "/workspace/mailbox",
    "state_dir": "~/.grok-mailbox",
    "multica": "multica",
    # Display names Grok Bot may @. Resolved to agent ids through `multica agent list`.
    "mention_allow": ["孙悟空"],
    # Issue prefixes Grok Bot may touch.
    "issue_prefixes": ["DENE"],
    # Bot-created issues are parked; an @ on them is what starts work.
    "create_status": "backlog",
    "create_waiting_for": "Kun 确认（由 Grok Bot 代建，执行人留空）",
    "limits": {"per_poll": 10, "create_per_day": 5, "comment_per_day": 30},
    "watch_hours": 24,
    "active_interval": 3,
    "active_seconds": 300,
}


def now():
    return dt.datetime.now(dt.timezone.utc)


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def load_config(path):
    cfg = json.loads(json.dumps(DEFAULTS))
    if path:
        with open(os.path.expanduser(path), encoding="utf-8") as f:
            user = json.load(f)
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(v)
            else:
                cfg[k] = v
    cfg["state_dir"] = os.path.expanduser(cfg["state_dir"])
    os.makedirs(os.path.join(cfg["state_dir"], "tmp"), exist_ok=True)
    return cfg


class State:
    """Local bridge memory: processed messages, tasks we issued, issues we watch."""

    def __init__(self, cfg):
        self.path = os.path.join(cfg["state_dir"], "state.json")
        self.audit_path = os.path.join(cfg["state_dir"], "audit.jsonl")
        try:
            with open(self.path, encoding="utf-8") as f:
                self.data = json.load(f)
        except FileNotFoundError:
            self.data = {}
        for k in ("seen", "tasks", "watch", "own_comments", "counters", "outq"):
            self.data.setdefault(k, [] if k in ("own_comments", "outq") else {})

    def queue(self, msg):
        """Park a message for the bot's inbox; flush() delivers it."""
        name = f"{int(time.time() * 1000)}-{msg['type']}-{uuid.uuid4().hex[:6]}.json"
        self.data["outq"].append({"name": name, "msg": msg})
        self.save()
        return name

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def audit(self, **rec):
        rec = {"ts": iso(now()), **rec}
        with open(self.audit_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def bump(self, kind, limit):
        day = now().strftime("%Y-%m-%d")
        key = f"{day}:{kind}"
        self.data["counters"] = {k: v for k, v in self.data["counters"].items() if k.startswith(day)}
        n = self.data["counters"].get(key, 0)
        if n >= limit:
            return False
        self.data["counters"][key] = n + 1
        return True

    def unbump(self, kind):
        """A failed Multica call is retried next poll; it must not eat the quota."""
        key = f"{now().strftime('%Y-%m-%d')}:{kind}"
        if self.data["counters"].get(key):
            self.data["counters"][key] -= 1


class Rejected(Exception):
    pass


# ---------------------------------------------------------------- transport

PULL_SCRIPT = r"""
set -eu
root=$1
mkdir -p "$root/outbox" "$root/inbox" "$root/processed"
for f in "$root"/outbox/*.json; do
  [ -f "$f" ] || continue
  printf '%s %s\n' "$(basename "$f")" "$(head -c 40000 "$f" | base64 | tr -d '\n')"
done
"""

ACK_SCRIPT = r"""
set -eu
root=$1; shift
for n in "$@"; do
  [ -f "$root/outbox/$n" ] && mv -f "$root/outbox/$n" "$root/processed/$n"
done
true
"""

WRITE_SCRIPT = r"""
set -eu
root=$1; name=$2
mkdir -p "$root/inbox"
cat > "$root/inbox/.$name.part"
mv -f "$root/inbox/.$name.part" "$root/inbox/$name"
"""


class Remote:
    def __init__(self, cfg):
        self.ssh = [os.path.expanduser(a) if a.startswith("~/") else a for a in cfg["ssh"]]
        self.root = cfg["remote_root"]

    def _sh(self, script, args, stdin=b""):
        # The script travels as one fixed string; every argument is quoted and
        # file names were validated by FILE_RE before they reach this point.
        argv = " ".join(shlex.quote(a) for a in [self.root] + args)
        cmd = self.ssh + [f"sh -c {shlex.quote(script)} mailbox {argv}"]
        # 255 = ssh itself failed (the DERP-relayed link drops now and then);
        # every script here is safe to repeat, so retry once.
        for attempt in (1, 2):
            try:
                p = subprocess.run(cmd, input=stdin, capture_output=True, timeout=60)
            except subprocess.TimeoutExpired:
                p = subprocess.CompletedProcess(cmd, 255, b"", b"ssh timed out after 60s")
            if p.returncode != 255 or attempt == 2:
                break
            time.sleep(5)
        if p.returncode != 0:
            raise RuntimeError(f"ssh failed ({p.returncode}): {p.stderr.decode(errors='replace').strip()[:400]}")
        return p.stdout.decode()

    def pull(self):
        out = []
        for line in self._sh(PULL_SCRIPT, []).splitlines():
            name, _, b64 = line.partition(" ")
            out.append((name, base64.b64decode(b64) if b64 else b""))
        return out

    def ack(self, names):
        if names:
            self._sh(ACK_SCRIPT, names)

    def write(self, name, msg):
        self._sh(WRITE_SCRIPT, [name], json.dumps(msg, ensure_ascii=False, indent=1).encode())


def flush(st, rm):
    """Deliver queued inbox messages in order; on a transport failure keep the
    rest for the next poll so an action already done in Multica never loses
    its reply."""
    sent = 0
    while st.data["outq"]:
        item = st.data["outq"][0]
        try:
            rm.write(item["name"], item["msg"])
        except RuntimeError as e:
            st.audit(sender="bridge", action="deliver", file=item["name"], decision="error", reason=str(e)[:300])
            break
        st.data["outq"].pop(0)
        st.save()
        sent += 1
    return sent


# ---------------------------------------------------------------- multica

class Multica:
    def __init__(self, cfg, dry_run=False):
        self.bin = cfg["multica"]
        self.tmp = os.path.join(cfg["state_dir"], "tmp")
        self.dry = dry_run
        self._agents = None

    def run(self, args, write=False):
        if self.dry and write:
            return {"dry_run": [self.bin] + args}
        p = subprocess.run([self.bin] + args + ["--output", "json"], cwd=self.tmp,
                           capture_output=True, text=True, timeout=90)
        if p.returncode != 0:
            raise RuntimeError(f"multica {' '.join(args[:3])} failed: {p.stderr.strip()[:400]}")
        try:
            return json.loads(p.stdout) if p.stdout.strip() else {}
        except json.JSONDecodeError:
            raise RuntimeError("multica returned non-JSON output; check CLI version and command support")

    def body_file(self, text):
        name = f"body-{uuid.uuid4().hex[:8]}.md"
        with open(os.path.join(self.tmp, name), "w", encoding="utf-8") as f:
            f.write(text)
        return name

    def agents(self):
        if self._agents is None:
            d = self.run(["agent", "list"])
            d = d if isinstance(d, list) else d.get("agents", [])
            self._agents = {a["id"]: a["name"] for a in d if not a.get("archived_at")}
        return self._agents

    def comment(self, issue, text):
        f = self.body_file(text)
        try:
            return self.run(["issue", "comment", "add", issue, "--content-file", f], write=True)
        finally:
            os.remove(os.path.join(self.tmp, f))

    def create(self, title, text, status, waiting_for):
        f = self.body_file(text)
        args = ["issue", "create", "--title", title, "--description-file", f, "--status", status]
        if status == "backlog" and waiting_for:
            args += ["--waiting-for", waiting_for]
        try:
            return self.run(args, write=True)
        finally:
            os.remove(os.path.join(self.tmp, f))

    def get(self, issue):
        return self.run(["issue", "get", issue])

    def comments_since(self, issue, since):
        d = self.run(["issue", "comment", "list", issue, "--since", since, "--compact"])
        return d if isinstance(d, list) else d.get("comments", [])


# ---------------------------------------------------------------- policy

def defang(text):
    """The bot's words are quoted, never executed: no platform mentions, bounded size."""
    text = str(text)[:MAX_TEXT]
    text = re.sub(r"mention://", "mention-blocked://", text, flags=re.I)
    return text


def quote_block(text):
    return "\n".join("> " + line for line in text.splitlines()) or "> （空）"


def check_issue(cfg, issue):
    if not isinstance(issue, str) or not ISSUE_RE.match(issue):
        raise Rejected(f"票号格式不对：{str(issue)[:40]!r}")
    if issue.split("-")[0] not in cfg["issue_prefixes"]:
        raise Rejected(f"不允许访问这个前缀的票：{issue}")
    return issue


def parse(raw, name):
    if len(raw) > MAX_FILE_BYTES:
        raise Rejected("消息太大")
    try:
        msg = json.loads(raw.decode("utf-8"))
    except Exception:
        raise Rejected("不是合法的 JSON")
    if not isinstance(msg, dict):
        raise Rejected("消息必须是 JSON 对象")
    mid = str(msg.get("id") or name.rsplit(".", 1)[0])
    if not ID_RE.match(mid):
        raise Rejected("id 格式不对")
    msg["id"] = mid
    return msg


# Deliberately structured read operations: no arbitrary argv, paths, credentials,
# global flags or shell. Keep the CLI's complete JSON (including page cursors).
QUERY_COMMANDS = {
    "issues": (["issue", "list"], {"project", "status", "assignee", "priority", "limit", "offset"}),
    "search_issues": (["issue", "search"], {"limit", "include-closed"}),
    "chats": (["chat", "list"], {"project", "since", "all-projects"}),
    "search_chats": (["chat", "search"], {"project", "since", "all-projects"}),
    "history": (["chat", "history"], {"session", "limit", "before"}),
    "context": (["issue", "context"], set()),
    "issue": (["issue", "get"], set()),
    "comments": (["issue", "comment", "list"], set()),
    "agents": (["agent", "list"], set()),
}


def query(cfg, mc, msg):
    kind = msg.get("query")
    if not isinstance(kind, str) or kind not in QUERY_COMMANDS:
        raise Rejected("未知查询；允许：" + ", ".join(QUERY_COMMANDS))
    base, allowed = QUERY_COMMANDS[kind]
    args = list(base)
    options = msg.get("options", {})
    if not isinstance(options, dict) or set(options) - allowed:
        raise Rejected("查询选项不在允许清单里")
    if kind in ("context", "issue", "comments"):
        args.append(check_issue(cfg, msg.get("issue")))
    if kind == "comments":
        args.append("--full")  # Includes resolved threads, without clipping bodies.
    if kind.startswith("search_"):
        term = msg.get("text")
        if not isinstance(term, str) or not term.strip() or term.startswith("-") or len(term) > MAX_TEXT:
            raise Rejected("搜索词为空、过长或以减号开头")
        args.append(term)
    if kind == "history" and not options.get("session"):
        raise Rejected("读聊天历史必须指定 options.session")
    for key, value in options.items():
        if key in ("all-projects", "include-closed"):
            if not isinstance(value, bool):
                raise Rejected(key + " 必须是布尔值")
            if value:
                args.append("--" + key)
        elif key in ("limit", "offset"):
            if type(value) is not int or value < (1 if key == "limit" else 0) or (key == "limit" and value > 100):
                raise Rejected(key + " 超出范围")
            args.append("--" + key + "=" + str(value))
        else:
            if not isinstance(value, str) or not value or len(value) > 1000 or "\x00" in value:
                raise Rejected(key + " 必须是非空字符串")
            args.append("--" + key + "=" + value)
    result = mc.run(args)
    return ("query " + kind, {"type": "result", "re": msg["id"], "ok": True, "result": result})


def handle(cfg, st, mc, msg):
    """Perform one whitelisted action. Returns (multica_action, reply_for_bot)."""
    action = msg.get("action")
    if action not in ALLOWED_ACTIONS:
        raise Rejected(f"动作「{action}」不在白名单里（只允许：{'、'.join(ALLOWED_ACTIONS)}）")
    if action == "query":
        return query(cfg, mc, msg)
    lim = cfg["limits"]
    header = f"📮 **来自 Grok Bot**（消息 `{msg['id']}`，经信箱桥接转达；以下为 Bot 原话，未经核验）"

    if action == "comment":
        issue = check_issue(cfg, msg.get("issue"))
        text = defang(msg.get("text", ""))
        if not text.strip():
            raise Rejected("评论内容为空")
        mention = ""
        who = msg.get("mention")
        if who:
            if who not in cfg["mention_allow"]:
                raise Rejected(f"不允许 @「{who}」（可 @：{'、'.join(cfg['mention_allow'])}）")
            ids = [i for i, n in mc.agents().items() if n == who]
            if len(ids) != 1:
                raise Rejected(f"找不到唯一叫「{who}」的智能体")
            mention = f"[@{who}](mention://agent/{ids[0]}) "
        if not st.bump("comment", lim["comment_per_day"]):
            raise Rejected("今天评论次数已到上限")
        body = f"{mention}{header}\n\n{quote_block(text)}\n"
        try:
            res = mc.comment(issue, body)
        except Exception:
            st.unbump("comment")
            raise
        cid = res.get("id") if isinstance(res, dict) else None
        if cid:
            st.data["own_comments"] = (st.data["own_comments"] + [cid])[-500:]
        st.data["watch"][issue] = {"since": iso(now()), "until": iso(now() + dt.timedelta(hours=cfg["watch_hours"]))}
        return (f"comment {issue}" + (f" @{who}" if who else ""),
                {"type": "ack", "re": msg["id"], "ok": True, "issue": issue,
                 "result": f"已在 {issue} 留言" + (f"并 @{who}" if who else "") + "；有人回复会转到你的 inbox"})

    if action == "create_issue":
        title = defang(msg.get("title", "")).strip().replace("\n", " ")[:MAX_TITLE]
        if not title:
            raise Rejected("新建票缺标题")
        if not st.bump("create", lim["create_per_day"]):
            raise Rejected("今天新建票次数已到上限")
        text = defang(msg.get("text", ""))
        desc = f"{header}\n\n{quote_block(text)}\n"
        try:
            res = mc.create(title, desc, cfg["create_status"], cfg["create_waiting_for"])
        except Exception:
            st.unbump("create")
            raise
        key = res.get("identifier") if isinstance(res, dict) else None
        if key:
            st.data["watch"][key] = {"since": iso(now()), "until": iso(now() + dt.timedelta(hours=cfg["watch_hours"]))}
        return (f"create_issue {key or '?'}",
                {"type": "ack", "re": msg["id"], "ok": True, "issue": key,
                 "result": f"已新建 {key or '(dry-run)'}，执行人留空、状态 {cfg['create_status']}；要开工请再发一条 comment 并 @ 智能体"})

    if action == "status":
        issue = check_issue(cfg, msg.get("issue"))
        d = mc.get(issue)
        names = mc.agents()
        last = mc.comments_since(issue, iso(now() - dt.timedelta(days=7)))
        last = [c for c in last if c.get("author_type") == "agent"]
        tail = last[-1]["content"][:800] if last else ""
        return (f"status {issue}",
                {"type": "status", "re": msg["id"], "issue": issue, "title": d.get("title"),
                 "status": d.get("status"), "assignee": names.get(d.get("assignee_id"), d.get("assignee_id")),
                 "last_activity_at": d.get("last_activity_at"), "latest_agent_comment": tail})

    # task_result: only for a task id the bridge itself issued; the issue comes
    # from our own record, never from the bot.
    tid = msg.get("task")
    task = st.data["tasks"].get(tid) if isinstance(tid, str) else None
    if not task:
        raise Rejected(f"不认识的任务 id：{str(tid)[:40]!r}")
    if task.get("done"):
        raise Rejected(f"任务 {tid} 已经回报过")
    text = defang(msg.get("text", ""))
    code = msg.get("exit_code")
    body = (f"📮 **Grok Bot 回报任务结果**（任务 `{tid}`" + (f"，退出码 `{code}`" if isinstance(code, int) else "") +
            f"）\n\n交代的任务：\n{quote_block(task['instructions'])}\n\nGrok Bot 的回报（原话，未经核验）：\n```text\n"
            f"{text.replace('```', 'ʼʼʼ')}\n```\n")
    res = mc.comment(task["issue"], body)
    cid = res.get("id") if isinstance(res, dict) else None
    if cid:
        st.data["own_comments"] = (st.data["own_comments"] + [cid])[-500:]
    task["done"] = iso(now())
    return (f"task_result {tid} -> comment {task['issue']}",
            {"type": "ack", "re": msg["id"], "ok": True, "issue": task["issue"], "result": "任务结果已贴回 Multica"})


# ---------------------------------------------------------------- cycle

def poll(cfg, dry_run=False):
    st, rm, mc = State(cfg), Remote(cfg), Multica(cfg, dry_run)
    summary = {"processed": 0, "rejected": 0, "replies": 0}
    acked = []
    flush(st, rm)
    for name, raw in sorted(rm.pull())[: cfg["limits"]["per_poll"]]:
        digest = hashlib.sha256(raw).hexdigest()[:16]
        if not FILE_RE.match(name):
            st.audit(sender="grok", file=name[:100], sha=digest, decision="rejected", reason="文件名不合规（未移动）")
            summary["rejected"] += 1
            continue
        if st.data["seen"].get(name) == digest:
            acked.append(name)
            continue
        rec = {"sender": "grok", "transport": cfg["ssh"][-1], "file": name, "sha": digest}
        try:
            msg = parse(raw, name)
            rec.update(id=msg["id"], claimed_from=str(msg.get("from", ""))[:40], action=str(msg.get("action"))[:40])
            done, reply = handle(cfg, st, mc, msg)
            rec.update(decision="allowed", multica=done)
            summary["processed"] += 1
        except Rejected as e:
            reply = {"type": "rejected", "re": rec.get("id", name), "reason": str(e)}
            rec.update(decision="rejected", reason=str(e))
            summary["rejected"] += 1
        except Exception as e:  # Multica/transport failure: keep the file for the next poll
            rec.update(decision="error", reason=str(e)[:400])
            if msg.get("action") != "query":
                st.audit(**rec)
                st.save()
                continue
            summary["rejected"] += 1
            reply = {"type": "error", "re": msg["id"], "ok": False,
                     "reason": "查询失败；检查 Mac 登录、CLI 版本及桥接审计日志"}
        if dry_run:
            rec["dry_run"] = True
        st.audit(**rec)
        st.data["seen"][name] = digest
        st.queue(reply)
        acked.append(name)
    summary["replies"] = relay_replies(cfg, st, mc)
    st.data["seen"] = dict(list(st.data["seen"].items())[-2000:])
    st.save()
    flush(st, rm)
    summary["undelivered"] = len(st.data["outq"])
    rm.ack(acked)
    return summary


def relay_replies(cfg, st, mc):
    """New comments on issues the bot touched go back to its inbox."""
    n = 0
    names = None
    for issue, w in list(st.data["watch"].items()):
        if w["until"] < iso(now()):
            del st.data["watch"][issue]
            continue
        try:
            comments = mc.comments_since(issue, w["since"])
        except Exception as e:
            st.audit(sender="bridge", action="watch", issue=issue, decision="error", reason=str(e)[:300])
            continue
        for c in comments:
            w["since"] = max(w["since"], c.get("created_at", w["since"]))
            if c.get("id") in st.data["own_comments"] or c.get("type") == "system" or c.get("author_type") == "system":
                continue
            names = names or mc.agents()
            author = names.get(c.get("author_id"), c.get("author_type", "?"))
            st.queue({"type": "reply", "issue": issue, "comment_id": c.get("id"), "author": author,
                      "at": c.get("created_at"), "text": c.get("content", "")[:MAX_TEXT]})
            st.audit(sender="bridge", action="relay_reply", issue=issue, comment=c.get("id"), author=author, decision="sent")
            st.data["own_comments"].append(c.get("id"))
            n += 1
        st.save()
    return n


def cmd_task(cfg, args):
    st, rm = State(cfg), Remote(cfg)
    issue = check_issue(cfg, args.issue)
    tid = "t-" + uuid.uuid4().hex[:10]
    st.data["tasks"][tid] = {"issue": issue, "instructions": args.instructions, "created": iso(now())}
    msg = {"type": "task", "id": tid, "issue": issue, "instructions": args.instructions,
           "reply_with": {"action": "task_result", "task": tid, "text": "<命令输出或结果摘要>", "exit_code": 0}}
    name = st.queue(msg)
    st.audit(sender="bridge", action="task_out", id=tid, issue=issue, decision="queued", file=name)
    flush(st, rm)
    print(json.dumps({"task": tid, "inbox_file": name, "delivered": not st.data["outq"]}, ensure_ascii=False))


INSTALL_SCRIPT = r"""
set -eu
root=$1; name=$2
mkdir -p "$root/inbox" "$root/outbox" "$root/processed"
cat > "$root/$name"
chmod +x "$root/$name"
"""


def cmd_setup_bot(cfg):
    """Create the mailbox on Grok and copy the credential-free helpers there."""
    rm = Remote(cfg)
    for rel in ("bot/mbox.py", "bot/cred-scan.sh", "bot/standing-instructions.md"):
        with open(os.path.join(HERE, rel), "rb") as f:
            rm._sh(INSTALL_SCRIPT, [os.path.basename(rel)], f.read())
    print(f"mailbox ready on {cfg['ssh'][-1]}:{cfg['remote_root']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=os.environ.get("GROK_MAILBOX_CONFIG"))
    ap.add_argument("--dry-run", action="store_true", help="don't write to Multica; still talks to Grok")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("poll")
    r = sub.add_parser("run")
    r.add_argument("--interval", type=int, default=60)
    t = sub.add_parser("task")
    t.add_argument("--issue", required=True)
    t.add_argument("--instructions", required=True)
    sub.add_parser("setup-bot")
    a = sub.add_parser("audit")
    a.add_argument("-n", type=int, default=20)
    args = ap.parse_args()
    cfg = load_config(args.config)

    if args.cmd == "poll":
        print(json.dumps(poll(cfg, args.dry_run), ensure_ascii=False))
    elif args.cmd == "run":
        active_until = 0.0
        while True:
            try:
                summary = poll(cfg, args.dry_run)
                if summary["processed"] or summary["rejected"] or summary["replies"]:
                    active_until = time.monotonic() + cfg["active_seconds"]
                print(iso(now()), json.dumps(summary, ensure_ascii=False), flush=True)
            except Exception as e:
                print(iso(now()), "poll error:", e, file=sys.stderr, flush=True)
            time.sleep(max(1, min(args.interval, cfg["active_interval"])) if time.monotonic() < active_until else max(1, args.interval))
    elif args.cmd == "setup-bot":
        cmd_setup_bot(cfg)
    elif args.cmd == "task":
        cmd_task(cfg, args)
    elif args.cmd == "audit":
        try:
            with open(State(cfg).audit_path, encoding="utf-8") as f:
                sys.stdout.writelines(f.readlines()[-args.n:])
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    main()
